package com.coursera.expertsurvey.database;

/**
 * Created by Victor Daniel Cortés Restrepo on 13/12/16.
 */

public class ConstantsDatabase {

    /**
     * Constantes correspondientes a la BASE DE DATOS.
     */
    public static final String DATABASE_NAME = "Surveys";
    public static final int DATABASE_VERSION = 1;

    /**
     * Constantes correspondientes a la tabla ENCUESTA.
     */
    public static final String TABLE_ENCUESTA           = "ENCUESTA";
    public static final String TABLE_ENCUESTA_NUMERO    = "numero";
    public static final String TABLE_ENCUESTA_NOMBRE      = "nombre";
    public static final String TABLE_ENCUESTA_FECHA      = "fecha_creacion";
    public static final String TABLE_ENCUESTA_CANTIDAD  = "cantidad";
    public static final String TABLE_ENCUESTA_VIGENCIA     = "vigencia";

    /**
     * Constantes correspondientes a la tabla CIUDAD.
     */
    public static final String TABLE_CIUDAD                 = "CIUDAD";
    public static final String TABLE_CIUDAD_ID              = "id_ciudad";
    public static final String TABLE_CIUDAD_NOMBRE          = "nombre";
    public static final String TABLE_CIUDAD_DEPARTMENTO_FK  = "id_departamento_fk";

    /**
     * Constantes correspondientes a la tabla CONTACTO.
     */
    public static final String TABLE_CONTACTO                   = "CONTACTO";
    public static final String TABLE_CONTACTO_ID                = "id_contacto";
    public static final String TABLE_CONTACTO_EMAIL             = "email";
    public static final String TABLE_CONTACTO_COD_PAIS_TEL      = "cod_pais_tel";
    public static final String TABLE_CONTACTO_COD_AREA_TEL      = "cod_area_tel";
    public static final String TABLE_CONTACTO_NUM_TEL           = "num_tel";
    public static final String TABLE_CONTACTO_TIPO_CONTACTO_FK  = "tipo_contacto_fk";
    public static final String TABLE_CONTACTO_DOCUMENTO_FK      = "documento_fk";
    public static final String TABLE_CONTACTO_TIPO_DOCUMENTO_FK = "id_tipo_documento_fk";

    /**
     * Constantes correspondientes a la tabla CONTINENTE.
     */
    public static final String TABLE_CONTINENTE         = "CONTINENTE";
    public static final String TABLE_CONTINENTE_ID      = "id_continente";
    public static final String TABLE_CONTINENTE_NOMBRE  = "nombre";

    /**
     * Constantes correspondientes a la tabla DEPARTAMENTO.
     */
    public static final String TABLE_DEPARTAMENTO           = "DEPARTAMENTO";
    public static final String TABLE_DEPARTAMENTO_ID        = "id_departamento";
    public static final String TABLE_DEPARTAMENTO_NOMBRE    = "nombre";
    public static final String TABLE_DEPARTAMENTO_REGION_FK = "id_region_fk";

    /**
     * Constantes correspondientes a la tabla DIRECCION.
     */
    public static final String TABLE_DIRECCION                      = "DIRECCION";
    public static final String TABLE_DIRECCION_ID                   = "id_direccion";
    public static final String TABLE_DIRECCION_DESCRIPCION          = "descripcion";
    public static final String TABLE_DIRECCION_CIUDAD_FK            = "id_ciudad_fk";
    public static final String TABLE_DIRECCION_TIPO_DOCUMENTO_FK    = "id_tipo_documento_fk";
    public static final String TABLE_DIRECCION_DOCUMENTO_FK         = "documento_fk";

    /**
     * Constantes correspondientes a la tabla OPCION.
     */
    public static final String TABLE_OPCION             = "OPCION";
    public static final String TABLE_OPCION_ID          = "id_opcion";
    public static final String TABLE_OPCION_ETIQUETA    = "etiqueta";
    public static final String TABLE_OPCION_ESTADO      = "estado";
    public static final String TABLE_OPCION_VALOR       = "valor";
    public static final String TABLE_OPCION_PREGUNTA_FK = "id_pregunta_fk";

    /**
     * Constantes correspondientes a la tabla PAIS.
     */
    public static final String TABLE_PAIS               = "PAIS";
    public static final String TABLE_PAIS_ID            = "id_pais";
    public static final String TABLE_PAIS_NOMBRE        = "nombre";
    public static final String TABLE_PAIS_CONTINENTE_FK = "id_continente_fk";

    /**
     * Constantes correspondientes a la tabla PERSONA.
     */
    public static final String TABLE_PERSONA                    = "PERSONA";
    public static final String TABLE_PERSONA_DOCUMENTO          = "documento";
    public static final String TABLE_PERSONA_TIPO_DOCUMENTO_FK  = "id_tipo_documento_fk";
    public static final String TABLE_PERSONA_NOMBRES            = "nombres";
    public static final String TABLE_PERSONA_PRIMER_APELLIDO    = "primer_apellido";
    public static final String TABLE_PERSONA_SEGUNDO_APELLIDO   = "segundo_apellido";
    public static final String TABLE_PERSONA_ESTADO_CIVIL       = "estado_civil";

    /**
     * Constantes correspondientes a la tabla PERSONA_ENCUESTA.
     */
    public static final String TABLE_PERSONA_ENCUESTA                   = "PERSONA_ENCUESTA";
    public static final String TABLE_PERSONA_ENCUESTA_ID                = "id_persona_encuesta";
    public static final String TABLE_PERSONA_ENCUESTA_ESTADO            = "estado";
    public static final String TABLE_PERSONA_ENCUESTA_FECHA             = "fecha";
    public static final String TABLE_PERSONA_ENCUESTA_NUMERO_FK         = "numero_fk";
    public static final String TABLE_PERSONA_ENCUESTA_DOCUMENTO_FK      = "documento_fk";
    public static final String TABLE_PERSONA_ENCUESTA_TIPO_DOCUMENTO_FK = "id_tipo_documento_fk";

    /**
     * Constantes correspondientes a la tabla PREGUNTA.
     */
    public static final String TABLE_PREGUNTA                   = "PREGUNTA";
    public static final String TABLE_PREGUNTA_ID                = "id_pregunta";
    public static final String TABLE_PREGUNTA_NUMERO_FK         = "numero_fk";
    public static final String TABLE_PREGUNTA_TEXTO             = "texto";
    public static final String TABLE_PREGUNTA_TIPO_RESPUESTA_FK = "tipo_respuesta_fk";

    /**
     * Constantes correspondientes a la tabla REGION.
     */
    public static final String TABLE_REGION         = "REGION";
    public static final String TABLE_REGION_ID      = "id_region";
    public static final String TABLE_REGION_NOMBRE  = "nombre";
    public static final String TABLE_REGION_PAIS_FK = "id_pais_fk";

    /**
     * Constantes correspondientes a la tabla RESPUESTA.
     */
    public static final String TABLE_RESPUESTA                      = "RESPUESTA";
    public static final String TABLE_RESPUESTA_ID                   = "id_respuesta";
    public static final String TABLE_RESPUESTA_VALOR                = "valor";
    public static final String TABLE_RESPUESTA_PREGUNTA_FK          = "id_pregunta_fk";
    public static final String TABLE_RESPUESTA_PERSONA_ENCUESTA_FK  = "id_persona_encuesta_fk";

    /**
     * Constantes correspondientes a la tabla TIPO_CONTACTO.
     */
    public static final String TABLE_TIPO_CONTACTO              = "TIPO_CONTACTO";
    public static final String TABLE_TIPO_CONTACTO_ID           = "id_tipo_contacto";
    public static final String TABLE_TIPO_CONTACTO_NOMBRE       = "nombre";
    public static final String TABLE_TIPO_CONTACTO_DESCRIPCION  = "descripcion";

    /**
     * Constantes correspondientes a la tabla TIPO_DOCUMENTO.
     */
    public static final String TABLE_TIPO_DOCUMENTO             = "TIPO_DOCUMENTO";
    public static final String TABLE_TIPO_DOCUMENTO_ID          = "id_tipo_documento";
    public static final String TABLE_TIPO_DOCUMENTO_NOMBRE      = "nombre";
    public static final String TABLE_TIPO_DOCUMENTO_DESCRIPCION = "descripcion";
    public static final String TABLE_TIPO_DOCUMENTO_ABREVIATURA = "abreviatura";

    /**
     * Constantes correspondientes a la tabla TIPO_RESPUESTA.
     */
    public static final String TABLE_TIPO_RESPUESTA = "TIPO_RESPUESTA";
    public static final String TABLE_TIPO_RESPUESTA_ID = "id_tipo_respuesta";
    public static final String TABLE_TIPO_RESPUESTA_NOMBRE = "nombre";
    public static final String TABLE_TIPO_RESPUESTA_DESCRIPCION = "descripcion";
}
