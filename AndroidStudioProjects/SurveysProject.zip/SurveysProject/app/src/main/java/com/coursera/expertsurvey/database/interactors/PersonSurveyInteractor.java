package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.PersonaEncuesta;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class PersonSurveyInteractor {


    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public PersonSurveyInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public PersonSurveyInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar una encuesta persona.
     * @param db, base de datos donde se buscara la encuesta persona.
     * @param cod, identificador de la encuesta persona a buscar.
     * @return personaEncuesta, registro de la encuesta persona buscada.
     */
    public PersonaEncuesta searchPersonSurvey(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ID,
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_FECHA, ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ESTADO,
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_NUMERO_FK, ConstantsDatabase.TABLE_PERSONA_ENCUESTA_DOCUMENTO_FK,
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_TIPO_DOCUMENTO_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_PERSONA_ENCUESTA,
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ID, fields, parameters);

        PersonaEncuesta personaEncuesta = new PersonaEncuesta();

        if (cursor.moveToFirst()) {
            personaEncuesta.setIdEncuestaPersona(cursor.getInt(0));
            personaEncuesta.setFecha(db.castDate(cursor.getString(1)));
            personaEncuesta.setEstado(cursor.getString(2));
            personaEncuesta.setNumeroEncuestaFK(cursor.getInt(3));
            personaEncuesta.setDocumentoFK(cursor.getString(4));
            personaEncuesta.setIdTipoDocumentoFK(cursor.getInt(5));
        }

        return personaEncuesta;
    }

    public PersonaEncuesta searchPersonSurveyRecord(DataBase db, int typeDoc, String doc, int numSurv) {
        String query = "SELECT * FROM " + ConstantsDatabase.TABLE_PERSONA_ENCUESTA
                + " WHERE " + ConstantsDatabase.TABLE_PERSONA_ENCUESTA_NUMERO_FK + " = " + numSurv
                + " AND " + ConstantsDatabase.TABLE_PERSONA_ENCUESTA_TIPO_DOCUMENTO_FK + " = " + typeDoc
                + " AND " + ConstantsDatabase.TABLE_PERSONA_ENCUESTA_DOCUMENTO_FK + " = " + doc;

        Cursor cursor = db.search(query);

        PersonaEncuesta personaEncuesta = new PersonaEncuesta();

        if (cursor.moveToFirst()) {
            personaEncuesta.setIdEncuestaPersona(cursor.getInt(0));
            personaEncuesta.setFecha(db.castDate(cursor.getString(1)));
            personaEncuesta.setEstado(cursor.getString(2));
            personaEncuesta.setNumeroEncuestaFK(cursor.getInt(3));
            personaEncuesta.setDocumentoFK(cursor.getString(4));
            personaEncuesta.setIdTipoDocumentoFK(cursor.getInt(5));
        }

        return personaEncuesta;
    }

    /**
     * Método que permite insertar una personaEncuesta.
     * @param db, base de datos en la cual se insertara la personaEncuesta.
     * @param personaEncuesta, personaEncuesta a insertar en la base de datos.
     */
    public void insertPersonSurvey(DataBase db, PersonaEncuesta personaEncuesta) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_FECHA, personaEncuesta.getFecha() + "");
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ESTADO, personaEncuesta.getEstado());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_NUMERO_FK, personaEncuesta.getNumeroEncuestaFK());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_DOCUMENTO_FK, personaEncuesta.getDocumentoFK());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_TIPO_DOCUMENTO_FK, personaEncuesta.getIdTipoDocumentoFK());

        db.insertRecord(ConstantsDatabase.TABLE_PERSONA_ENCUESTA, contentValues);
    }

    /**
     * Método que permite modificar el registro de una personaEncuesta.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param personaEncuesta, personaEncuesta a la cual se le modificaran los datos.
     */
    public void modifyPersonSurvey(DataBase db, PersonaEncuesta personaEncuesta) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_FECHA, personaEncuesta.getFecha() + "");
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ESTADO, personaEncuesta.getEstado());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_NUMERO_FK, personaEncuesta.getNumeroEncuestaFK());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_DOCUMENTO_FK, personaEncuesta.getDocumentoFK());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ENCUESTA_TIPO_DOCUMENTO_FK, personaEncuesta.getIdTipoDocumentoFK());

        db.editRecord(ConstantsDatabase.TABLE_PERSONA_ENCUESTA, contentValues, ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ID, personaEncuesta.getIdEncuestaPersona()+"");
    }

    /**
     * Método que permite eliminar una encuesta persona.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deletePersonSurvey(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_PERSONA_ENCUESTA, ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ID, id+"");
    }

    /**
     * Método que permite obtener todas las encuesta persona.
     * @param db, base de datos donde se encuentran los registros.
     * @return personasEncuesta, lista de las personasEncuesta registradas.
     */
    public ArrayList<PersonaEncuesta> getPersonsSurvey(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_PERSONA_ENCUESTA);
        ArrayList<PersonaEncuesta> personasEncuesta = new ArrayList<>();

        while (registros.moveToNext()) {
            PersonaEncuesta personaEncuesta = new PersonaEncuesta();
            personaEncuesta.setIdEncuestaPersona(registros.getInt(0));
            personaEncuesta.setFecha(db.castDate(registros.getString(1)));
            personaEncuesta.setEstado(registros.getString(2));
            personaEncuesta.setNumeroEncuestaFK(registros.getInt(3));
            personaEncuesta.setDocumentoFK(registros.getString(4));
            personaEncuesta.setIdTipoDocumentoFK(registros.getInt(5));
            personasEncuesta.add(personaEncuesta);
        }

        return personasEncuesta;
    }
}
