package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.TipoRespuesta;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class TypeResponseInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public TypeResponseInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public TypeResponseInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar un tipo respuesta.
     * @param db, base de datos donde se buscara el tipo respuesta.
     * @param cod, identificador del tipo respuesta a buscar.
     * @return tipoRespuesta, registro del tipo respuesta buscado.
     */
    public TipoRespuesta searchTypeResponse(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_TIPO_RESPUESTA_ID,
                ConstantsDatabase.TABLE_TIPO_RESPUESTA_NOMBRE, ConstantsDatabase.TABLE_TIPO_RESPUESTA_DESCRIPCION};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_TIPO_RESPUESTA,
                ConstantsDatabase.TABLE_TIPO_RESPUESTA_ID, fields, parameters);

        TipoRespuesta tipoRespuesta = new TipoRespuesta();

        if (cursor.moveToFirst()) {
            tipoRespuesta.setIdTipoRespuesta(cursor.getInt(0));
            tipoRespuesta.setNombre(cursor.getString(1));
            tipoRespuesta.setDescripcion(cursor.getString(2));
        }

        return tipoRespuesta;
    }

    /**
     * Método que permite insertar un tipoRespuesta.
     * @param db, base de datos en la cual se insertara el tipoRespuesta.
     * @param tipoRespuesta, tipoRespuesta a insertar en la base de datos.
     */
    public void insertTypeResponse(DataBase db, TipoRespuesta tipoRespuesta) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_TIPO_RESPUESTA_NOMBRE, tipoRespuesta.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_RESPUESTA_DESCRIPCION, tipoRespuesta.getDescripcion());

        db.insertRecord(ConstantsDatabase.TABLE_TIPO_RESPUESTA, contentValues);
    }

    /**
     * Método que permite modificar el registro de un tipoRespuesta.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param tipoRespuesta, tipoRespuesta a la cual se le modificaran los datos.
     */
    public void modifyTypeResponse(DataBase db, TipoRespuesta tipoRespuesta) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_TIPO_RESPUESTA_ID, tipoRespuesta.getIdTipoRespuesta());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_RESPUESTA_NOMBRE, tipoRespuesta.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_RESPUESTA_DESCRIPCION, tipoRespuesta.getDescripcion());

        db.editRecord(ConstantsDatabase.TABLE_TIPO_RESPUESTA, contentValues, ConstantsDatabase.TABLE_TIPO_RESPUESTA_ID,
                tipoRespuesta.getIdTipoRespuesta()+"");
    }

    /**
     * Método que permite eliminar un tipo respuesta.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteTypeResponse(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_TIPO_RESPUESTA, ConstantsDatabase.TABLE_TIPO_RESPUESTA_ID, id+"");
    }

    /**
     * Método que permite obtener todos los tipos respuesta.
     * @param db, base de datos donde se encuentran los registros.
     * @return tiposRespuesta, lista de los tipos respuesta registrados.
     */
    public ArrayList<TipoRespuesta> getTypesResponse(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_TIPO_RESPUESTA);
        ArrayList<TipoRespuesta> tiposRespuesta = new ArrayList<>();

        while (registros.moveToNext()) {
            TipoRespuesta tipoRespuesta = new TipoRespuesta();
            tipoRespuesta.setIdTipoRespuesta(registros.getInt(0));
            tipoRespuesta.setNombre(registros.getString(1));
            tipoRespuesta.setDescripcion(registros.getString(2));
            tiposRespuesta.add(tipoRespuesta);
        }

        return tiposRespuesta;
    }
}
