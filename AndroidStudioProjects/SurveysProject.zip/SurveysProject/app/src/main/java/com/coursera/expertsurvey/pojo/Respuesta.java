package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Respuesta {

    /**
     * Atributos de la clase.
     */
    private int idRespuesta;
    private int valor;
    private int idPreguntaFK;
    private int idPersonaEncuestaFK;

    /**
     * Método constructor por default de la clase.
     */
    public Respuesta() {
    }

    /**
     * Método constructor de la clase.
     * @param valor, peso de la pregunta para análisis.
     * @param idPreguntaFK, pregunta a la cual pertenece la respuesta.
     * @param idPersonaEncuestaFK, encuesta diligenciada por la persona a la cual pertenece.
     */
    public Respuesta(int valor, int idPreguntaFK, int idPersonaEncuestaFK) {
        this.valor = valor;
        this.idPreguntaFK = idPreguntaFK;
        this.idPersonaEncuestaFK = idPersonaEncuestaFK;
    }

    /**
     * Método accesor del atributo idRespuesta.
     * @return idRespuesta, valor del atributo establecido.
     */
    public int getIdRespuesta() {
        return idRespuesta;
    }

    /**
     * Método modificador correspondiente al valor del atributo idRespuesta.
     * @param idRespuesta, valor que se va a establecer en el atributo.
     */
    public void setIdRespuesta(int idRespuesta) {
        this.idRespuesta = idRespuesta;
    }

    /**
     * Método accesor del atributo valor.
     * @return valor, valor del atributo establecido.
     */
    public int getValor() {
        return valor;
    }

    /**
     * Método modificador correspondiente al valor del atributo valor.
     * @param valor, valor que se va a establecer en el atributo.
     */
    public void setValor(int valor) {
        this.valor = valor;
    }

    /**
     * Método accesor del atributo idPreguntaFK.
     * @return idPreguntaFK, valor del atributo establecido.
     */
    public int getIdPreguntaFK() {
        return idPreguntaFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idPreguntaFK.
     * @param idPreguntaFK, valor que se va a establecer en el atributo.
     */
    public void setIdPreguntaFK(int idPreguntaFK) {
        this.idPreguntaFK = idPreguntaFK;
    }

    /**
     * Método accesor del atributo idPersonaEncuestaFK.
     * @return idPersonaEncuestaFK, valor del atributo establecido.
     */
    public int getIdPersonaEncuestaFK() {
        return idPersonaEncuestaFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idPersonaEncuestaFK.
     * @param idPersonaEncuestaFK, valor que se va a establecer en el atributo.
     */
    public void setIdPersonaEncuestaFK(int idPersonaEncuestaFK) {
        this.idPersonaEncuestaFK = idPersonaEncuestaFK;
    }
}
