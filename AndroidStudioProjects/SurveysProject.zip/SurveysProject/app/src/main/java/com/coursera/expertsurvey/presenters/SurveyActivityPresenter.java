package com.coursera.expertsurvey.presenters;

import android.content.Context;

import com.coursera.expertsurvey.adapters.ListAdapterQuestionOption;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.database.interactors.OptionInteractor;
import com.coursera.expertsurvey.database.interactors.PersonSurveyInteractor;
import com.coursera.expertsurvey.database.interactors.QuestionInteractor;
import com.coursera.expertsurvey.database.interactors.ResponseInteractor;
import com.coursera.expertsurvey.database.interactors.SurveyInteractor;
import com.coursera.expertsurvey.database.interactors.TypeResponseInteractor;
import com.coursera.expertsurvey.pojo.Encuesta;
import com.coursera.expertsurvey.pojo.Opcion;
import com.coursera.expertsurvey.pojo.PersonaEncuesta;
import com.coursera.expertsurvey.pojo.Pregunta;
import com.coursera.expertsurvey.pojo.Respuesta;
import com.coursera.expertsurvey.pojo.TipoRespuesta;
import com.coursera.expertsurvey.presenters.interfaces.ISurveyActivityPresenter;
import com.coursera.expertsurvey.viewmodel.ISurveyActivityView;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 20/12/16.
 */

public class SurveyActivityPresenter implements ISurveyActivityPresenter {

    /**
     * Atributos de la clase.
     */
    private Context context;
    private OptionInteractor optionInteractor;
    private SurveyInteractor surveyInteractor;
    private ResponseInteractor responseInteractor;
    private QuestionInteractor questionInteractor;
    private ISurveyActivityView iSurveyActivityView;
    private TypeResponseInteractor typeResponseInteractor;
    private PersonSurveyInteractor personSurveyInteractor;

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista principal.
     * @param iSurveyActivityView, instacia de la interface de la vista principal.
     */
    public SurveyActivityPresenter(Context context, ISurveyActivityView iSurveyActivityView) {
        this.context = context;
        this.iSurveyActivityView = iSurveyActivityView;
    }

    /**
     * Método que permite buscar la una encuesta.
     * @param numEncuesta, identifiacdor de la encuesta a buscar.
     * @return encuesta, objeto de tipo encuesta buscado.
     */
    @Override
    public Encuesta searchSurvey(int numEncuesta) {
        surveyInteractor = new SurveyInteractor(context);
        Encuesta encuesta = surveyInteractor.searchSurvey(new DataBase(context), numEncuesta);

        if(encuesta != null){
            return encuesta;
        }
        else {
            return null;
        }
    }

    /**
     * Método que permite obtener la lista de preguntas pertenecientes a una encuesta,
     * @param numEncuesta, identifiacdor de la encuesta para obtener las preguntas.
     * @return preguntas, lista de preguntas pertenecientes a una sola encuesta.
     */
    @Override
    public ArrayList<Pregunta> listQuestions(int numEncuesta) {
        questionInteractor = new QuestionInteractor(context);
        return questionInteractor.getQuestionsSurvey(new DataBase(context), numEncuesta);
    }

    /**
     * Método que permite obtener la lista de opciones pertenecientes a una pregunta.
     * @param idPregunta, identificador de la pregunta para obtener las opciones.
     * @return opciones, lista de opciones pertenecientes a una sola pregunta.
     */
    @Override
    public ArrayList<Opcion> listOptions(int idPregunta) {
        optionInteractor = new OptionInteractor(context);
        return optionInteractor.getOptionsQuestion(new DataBase(context), idPregunta);
    }

    /**
     * Método que permite mostrar la lista de opciones en la vista.
     * @param tipoRespuesta, tipo de respuesta que permite determinar los componentes de la vista a cargar.
     * @param opciones, lista de opciones a mostrar en la vista.
     */
    @Override
    public void showOptionsListView(TipoRespuesta tipoRespuesta, ArrayList<Opcion> opciones) {
        ListAdapterQuestionOption adapter = new ListAdapterQuestionOption(context, opciones, tipoRespuesta.getNombre());
        iSurveyActivityView.initializeAdapterListView(adapter);

        if(tipoRespuesta.getNombre().equals("Unica")) {
            iSurveyActivityView.listItemListenerCombo(opciones);
        }
        else {
            iSurveyActivityView.listItemListenerCheck(opciones);
        }
    }

    /**
     * Método que permite guardar una persona encuesta.
     * @param personaEncuesta, persona encuesta a guardar.
     */
    @Override
    public void savePersonSurvey(PersonaEncuesta personaEncuesta) {
        personSurveyInteractor = new PersonSurveyInteractor(context);
        personSurveyInteractor.insertPersonSurvey(new DataBase(context), personaEncuesta);
    }

    /**
     * Método que permite buscar una persona encuesta.
     */
    @Override
    public PersonaEncuesta searchPersonSurvey(int typeDoc, String doc, int numSurv) {
        return personSurveyInteractor.searchPersonSurveyRecord(new DataBase(context), typeDoc, doc, numSurv);
    }

    /**
     * Método que permite guardar la respuesta a una pregunta de la encuesta.
     */
    @Override
    public void saveResponse(Respuesta respuesta) {
        responseInteractor = new ResponseInteractor(context);
        responseInteractor.insertResponse(new DataBase(context), respuesta);
    }

    /**
     * Método que permite buscar el tipo de respuesta.
     * @param idTipo, identificador del tipo de respuesta a buscar.
     * @return tipoRespuesta, objeto de tipo respuesta buscado.
     */
    @Override
    public TipoRespuesta getTypeResponse(int idTipo) {
        typeResponseInteractor = new TypeResponseInteractor(context);
        return typeResponseInteractor.searchTypeResponse(new DataBase(context),idTipo);
    }
}
