package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Contacto {

    /**
     * Atributos de la clase.
     */
    private int idContacto;
    private String email;
    private String codPaisTel;
    private String codAreaTel;
    private String numeroTel;
    private int idTipoContactoFK;
    private int idTipoDocumentoFK;
    private String documentoFK;

    /**
     * Método constructor por default de la clase.
     */
    public Contacto() {
    }

    /**
     * Método constructor de la clase.
     * @param email, email de cotacto.
     * @param codPaisTel, código del pais para el teléfono.
     * @param codAreaTel, código de area para el teléfono.
     * @param numeroTel, número de teléfono.
     * @param idTipoContactoFK, identificador del tipo de contacto.
     * @param idTipoDocumentoFK, identificador del tipo de documento de la persona.
     * @param documentoFK, documento de identificación de la persona.
     */
    public Contacto(String email, String codPaisTel, String codAreaTel, String numeroTel,
                    int idTipoContactoFK, int idTipoDocumentoFK, String documentoFK) {
        this.email = email;
        this.codPaisTel = codPaisTel;
        this.codAreaTel = codAreaTel;
        this.numeroTel = numeroTel;
        this.idTipoContactoFK = idTipoContactoFK;
        this.idTipoDocumentoFK = idTipoDocumentoFK;
        this.documentoFK = documentoFK;
    }

    /**
     * Método accesor del atributo idContacto.
     * @return idContacto, valor del atributo establecido.
     */
    public int getIdContacto() {
        return idContacto;
    }

    /**
     * Método modificador correspondiente al valor del atributo idContacto.
     * @param idContacto, valor que se va a establecer en el atributo.
     */
    public void setIdContacto(int idContacto) {
        this.idContacto = idContacto;
    }

    /**
     * Método accesor del atributo email.
     * @return email, valor del atributo establecido.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Método modificador correspondiente al valor del atributo email.
     * @param email, valor que se va a establecer en el atributo.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Método accesor del atributo codPaisTel.
     * @return codPaisTel, valor del atributo establecido.
     */
    public String getCodPaisTel() {
        return codPaisTel;
    }

    /**
     * Método modificador correspondiente al valor del atributo codPaisTel.
     * @param codPaisTel, valor que se va a establecer en el atributo.
     */
    public void setCodPaisTel(String codPaisTel) {
        this.codPaisTel = codPaisTel;
    }

    /**
     * Método accesor del atributo codAreaTel.
     * @return codAreaTel, valor del atributo establecido.
     */
    public String getCodAreaTel() {
        return codAreaTel;
    }

    /**
     * Método modificador correspondiente al valor del atributo codAreaTel.
     * @param codAreaTel, valor que se va a establecer en el atributo.
     */
    public void setCodAreaTel(String codAreaTel) {
        this.codAreaTel = codAreaTel;
    }

    /**
     * Método accesor del atributo numeroTel.
     * @return numeroTel, valor del atributo establecido.
     */
    public String getNumeroTel() {
        return numeroTel;
    }

    /**
     * Método modificador correspondiente al valor del atributo numeroTel.
     * @param numeroTel, valor que se va a establecer en el atributo.
     */
    public void setNumeroTel(String numeroTel) {
        this.numeroTel = numeroTel;
    }

    /**
     * Método accesor del atributo idTipoContactoFK.
     * @return idTipoContactoFK, valor del atributo establecido.
     */
    public int getIdTipoContactoFK() {
        return idTipoContactoFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idTipoContactoFK.
     * @param idTipoContactoFK, valor que se va a establecer en el atributo.
     */
    public void setIdTipoContactoFK(int idTipoContactoFK) {
        this.idTipoContactoFK = idTipoContactoFK;
    }

    /**
     * Método accesor del atributo idTipoDocumentoFK.
     * @return idTipoDocumentoFK, valor del atributo establecido.
     */
    public int getIdTipoDocumentoFK() {
        return idTipoDocumentoFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idTipoDocumentoFK.
     * @param idTipoDocumentoFK, valor que se va a establecer en el atributo.
     */
    public void setIdTipoDocumentoFK(int idTipoDocumentoFK) {
        this.idTipoDocumentoFK = idTipoDocumentoFK;
    }

    /**
     * Método accesor del atributo documentoFK.
     * @return documentoFK, valor del atributo establecido.
     */
    public String getDocumentoFK() {
        return documentoFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo documentoFK.
     * @param documentoFK, valor que se va a establecer en el atributo.
     */
    public void setDocumentoFK(String documentoFK) {
        this.documentoFK = documentoFK;
    }
}
