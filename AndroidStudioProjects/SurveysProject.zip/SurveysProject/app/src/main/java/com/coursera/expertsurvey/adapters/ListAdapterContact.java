package com.coursera.expertsurvey.adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coursera.expertsurvey.R;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.database.interactors.TypeContactInteractor;
import com.coursera.expertsurvey.pojo.Contacto;
import com.coursera.expertsurvey.pojo.TipoContacto;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 19/12/16.
 */

public class ListAdapterContact extends RecyclerView.Adapter<ListAdapterContact.ListAdapterContactViewHolder> {

    /**
     * Atributos de la clase.
     */
    private ArrayList<Contacto> contactos;
    private Activity activity;
    private TypeContactInteractor typeContactInteractor;
    private DataBase dataBase;

    /**
     * Método constructor de la clase.
     * @param contactos, lista de contactos.
     * @param activity, actividad en la que se encuentra el recycler.
     * @param dataBase, base de datos de la aplicación.
     */
    public ListAdapterContact(ArrayList<Contacto> contactos, Activity activity, DataBase dataBase) {
        this.contactos = contactos;
        this.activity = activity;
        this.dataBase = dataBase;
        typeContactInteractor = new TypeContactInteractor();
    }

    /**
     * Método que permite inflar el layout pasandolo al view holder para realizar el uso de los views.
     * @param parent, grupo de views a los cuales se realizará la inflación.
     * @param viewType, tipo de la view a la que se le realizará la inflación.
     * @return
     */
    @Override
    public ListAdapterContactViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_card_view, parent, false);
        return new ListAdapterContactViewHolder(view);
    }

    /**
     * Método que realiza la asociación de cada elemento de a los view de la vista.
     * @param listAdapterContactViewHolder, view al cual se le realizará la asociación de los elementos.
     * @param position, posicion del elemnto que se va asociar en la lista.
     */
    @Override
    public void onBindViewHolder(ListAdapterContactViewHolder listAdapterContactViewHolder, int position) {
        Contacto contacto = contactos.get(position);
        TipoContacto tipoContacto = consultTypeContact(contacto.getIdTipoContactoFK());
        listAdapterContactViewHolder.tvContactCCV.setText(consultContactFields(tipoContacto, contacto));
        listAdapterContactViewHolder.ivTypeContactCCV.setImageResource(consultContactIcon(tipoContacto));
    }

    /**
     * Método que permite conocer la cantidad de elementos de la lista.
     * @return size, cantidad de elementos de la lista.
     */
    @Override
    public int getItemCount() {
        return contactos.size();
    }

    /**
     * Clase statica que permite la interacción entre los objetos y las views.
     */
    public static class ListAdapterContactViewHolder extends RecyclerView.ViewHolder {

        /**
         * Views de la vista.
         */
        private LinearLayout llContactCardCCV;
        private TextView tvContactCCV;
        private ImageView ivTypeContactCCV;

        /**
         * Método constructor de la clase.
         * @param itemView, vista a la cual pertenecen los elementos.
         */
        public ListAdapterContactViewHolder(View itemView) {
            super(itemView);

            llContactCardCCV = (LinearLayout) itemView.findViewById(R.id.llContactCardCCV);
            tvContactCCV = (TextView) itemView.findViewById(R.id.tvContactCCV);
            ivTypeContactCCV = (ImageView) itemView.findViewById(R.id.ivTypeContactCCV);
        }
    }

    /**
     * Método que consulta el tipo de contacto.
     * @param idType, identificador del tipo de contacto a buscar.
     * @return tipoContacto, tipo de contacto consultado en la base de datos.
     */
    private TipoContacto consultTypeContact(int idType) {
        return typeContactInteractor.searchTypeContact(dataBase, idType);
    }

    /**
     * Método que permite consultar el dato del número de telefono o correo del contacto.
     * @param tipoContacto, tipo de contacto usado para identificar el dato.
     * @param contacto, contacto para establecer el valor según su tipo de contacto.
     * @return el campo correspondiente según su tipo de contacto.
     */
    private String consultContactFields(TipoContacto tipoContacto, Contacto contacto) {
        switch(tipoContacto.getIdTipoContacto()) {
            case 1:
                return contacto.getEmail();

            default:
                return contacto.getCodPaisTel()+"-"+contacto.getCodAreaTel()+"-"+contacto.getNumeroTel();
        }
    }

    /**
     * Método que permite consultar el icono según el tipo de contacto.
     * @param tipoContacto, tipo de contacto usado para determinar el icono a mostrar.
     * @return el icono usado según el tipo de contacto.
     */
    private int consultContactIcon(TipoContacto tipoContacto){
        switch(tipoContacto.getIdTipoContacto()) {
            case 1:
                return R.drawable.ic_email;

            case 2:
                return R.drawable.ic_cell_phone;

            default:
                return R.drawable.ic_phone;
        }
    }
}
