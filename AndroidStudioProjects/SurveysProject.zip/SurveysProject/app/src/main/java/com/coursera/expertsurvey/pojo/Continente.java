package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Continente {

    /**
     * Atributos de la clase.
     */
    private int idContinente;
    private String nombre;

    /**
     * Método constructor por default de la clase.
     */
    public Continente() {
    }

    /**
     * Método constructor de la clase.
     * @param nombre, nombre de la ciudad.
     */
    public Continente(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método accesor del atributo idContinente.
     * @return idContinente, valor del atributo establecido.
     */
    public int getIdContinente() {
        return idContinente;
    }

    /**
     * Método modificador correspondiente al valor del atributo idContinente.
     * @param idContinente, valor que se va a establecer en el atributo.
     */
    public void setIdContinente(int idContinente) {
        this.idContinente = idContinente;
    }

    /**
     * Método accesor del atributo nombre.
     * @return nombre, valor del atributo establecido.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombre.
     * @param nombre, valor que se va a establecer en el atributo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
