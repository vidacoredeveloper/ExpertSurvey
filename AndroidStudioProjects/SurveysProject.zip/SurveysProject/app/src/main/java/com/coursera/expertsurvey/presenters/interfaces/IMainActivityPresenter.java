package com.coursera.expertsurvey.presenters.interfaces;

/**
 * Created by Victor Daniel Cortés Restrepo on 13/12/16.
 */

public interface IMainActivityPresenter {

    /**
     * Método que permite extraer las encuestas de la base de datos.
     */
    public void getSurveysDataBase();

    /**
     * Método que permite mostrar las encuestas en la vista.
     */
    public void showPollsReclyclerView();
}
