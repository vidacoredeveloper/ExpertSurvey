package com.coursera.expertsurvey;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.coursera.expertsurvey.adapters.ListAdapterContact;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Contacto;
import com.coursera.expertsurvey.pojo.Persona;
import com.coursera.expertsurvey.pojo.TipoDocumento;
import com.coursera.expertsurvey.presenters.ProfileActivityPresenter;
import com.coursera.expertsurvey.presenters.interfaces.IProfileActivityPresenter;
import com.coursera.expertsurvey.viewmodel.IProfileActivityView;

import java.util.ArrayList;

public class ProfileActivity extends AppCompatActivity implements IProfileActivityView {

    /**
     * Componentes de la vista.
     */
    private Button btnSearchAP;
    private RecyclerView rvContactAP;
    private Spinner spDocumentTypeAP;
    private EditText tietDocumentoAP;
    private InputMethodManager inputMethodManager;
    private TextView tvDataNameAP, tvDataFirstSurnameAP, tvDataSecondSurnameAP, tvDataCivilStatusAP;

    /**
     * Atributos de la vista.
     */
    private Persona persona;
    private IProfileActivityPresenter presenter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        initializeComponents();
    }

    /**
     * Método que inicializa los componentes gráficos y lógicos que pertenecen a la vista.
     */
    @Override
    public void initializeComponents() {
        btnSearchAP = (Button) findViewById(R.id.btnSearchAP);
        rvContactAP = (RecyclerView) findViewById(R.id.rvContactAP);
        spDocumentTypeAP = (Spinner) findViewById(R.id.spDocumentTypeAP);
        tietDocumentoAP = (EditText) findViewById(R.id.tietDocumentoAP);
        tvDataNameAP = (TextView) findViewById(R.id.tvDataNameAP);
        tvDataFirstSurnameAP = (TextView) findViewById(R.id.tvDataFirstSurnameAP);
        tvDataSecondSurnameAP = (TextView) findViewById(R.id.tvDataSecondSurnameAP);
        tvDataCivilStatusAP = (TextView) findViewById(R.id.tvDataCivilStatusAP);
        inputMethodManager = (InputMethodManager)getSystemService(getBaseContext().INPUT_METHOD_SERVICE);

        setLayoutRecyclerView();
        establishListenerSpinner();

        presenter = new ProfileActivityPresenter(this, getBaseContext());
        loadSpinner();
        cleanDataFields();
    }

    @Override
    public void loadSpinner() {
        ArrayAdapter adapter = presenter.getTypeDocument();
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDocumentTypeAP.setAdapter(adapter);
    }

    /**
     * Método que permite la asignacion de la organización y orientación de los elementos
     * en le recycler view.
     */
    @Override
    public void setLayoutRecyclerView() {
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        rvContactAP.setLayoutManager(llm);
    }

    /**
     * Método que permite generar el adaptador de la lista de los contactos.
     */
    @Override
    public ListAdapterContact initializeListAdapterSurvey(ArrayList<Contacto> contactos) {
        return new ListAdapterContact(contactos, this, new DataBase(getBaseContext()));
    }

    /**
     * Método que permite la inicialización del adaptador del recycler view.
     */
    @Override
    public void initializeAdapterRecyclerView(ListAdapterContact listAdapterContact) {
        rvContactAP.setAdapter(listAdapterContact);
    }

    /**
     * Método que permite obtener el teclado virtual del android.
     * @param view, vista desde la cual se ejecuta el método.
     */
    @Override
    public void controlGraphicsComponents(View view) {
        inputMethodManager.hideSoftInputFromWindow(tietDocumentoAP.getWindowToken(), 1);
        btnSearchAP.setEnabled(true);
        rvContactAP.setAdapter(null);
        cleanDataFields();
    }

    /**
     * Método que permite encontrar una persona.
     * @param view, vista desde la cual se ejecuta el método.
     */
    @Override
    public void searchPerson(View view) {

        if( (spDocumentTypeAP.getSelectedItemId() != 0) && (!tietDocumentoAP.getText().toString().equals("")) ) {
            TipoDocumento tipo = (TipoDocumento) spDocumentTypeAP.getSelectedItem();
            persona = presenter.searchPerson(tipo.getIdTipoDocumento(), tietDocumentoAP.getText().toString());
            if(persona!=null){

                btnSearchAP.setEnabled(false);
                inputMethodManager.hideSoftInputFromWindow(tietDocumentoAP.getWindowToken(), 0);

                tvDataNameAP.setText(persona.getNombres());
                tvDataFirstSurnameAP.setText(persona.getPrimerApellido());
                tvDataSecondSurnameAP.setText(persona.getSegundoApellido());
                tvDataCivilStatusAP.setText(persona.getEstadoCivil());

                presenter.getContactsPerson(persona.getIdTipoDocumentoFK(), persona.getDocumento());
            }
            else {
                Snackbar snackbar = Snackbar.make(view, "No se encontro una persona con ese tipo de documento y esa " +
                        "identificación.", Snackbar.LENGTH_SHORT);
                snackbar.show();
            }
        }
        else {
            Snackbar snackbar = Snackbar.make(view, "Por favor seleccione un tipo de documento y digite un documento.",
                    Snackbar.LENGTH_SHORT);
            snackbar.show();
        }
    }

    /**
     * Método que permite iniciar con la encuesta.
     * @param view, vista desde la cual se ejecuta el método.
     */
    @Override
    public void goSurvey(View view) {
        if(!tvDataNameAP.getText().toString().isEmpty()){
            MainActivity.persona = persona;

            Intent intent = new Intent(this, SurveyActivity.class);
            intent.putExtra("idSurvey", getIntent().getExtras().getInt("idSurvey"));
            startActivity(intent);
        }
        else {
            Snackbar snackbar = Snackbar.make(view, "Por favor buscar primero una persona", Snackbar.LENGTH_SHORT);
            snackbar.show();
        }
    }

    /**
     * Método que permite eliminar el texto de los text views de los datos.
     */
    @Override
    public void cleanDataFields() {
        tvDataNameAP.setText("");
        tvDataCivilStatusAP.setText("");
        tvDataFirstSurnameAP.setText("");
        tvDataSecondSurnameAP.setText("");
    }

    /**
     * Método que permite eliminar el texto de los text views del buscador.
     */
    @Override
    public void cleanFieldsSearch() {
        spDocumentTypeAP.setSelection(0);
        tietDocumentoAP.setText("");
    }

    /**
     * Método que permite establecer el escuchador del spinner.
     */
    @Override
    public void establishListenerSpinner() {
        spDocumentTypeAP.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                cleanDataFields();
                rvContactAP.setAdapter(null);
                btnSearchAP.setEnabled(true);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK){
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
