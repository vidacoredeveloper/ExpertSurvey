package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Ciudad;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class CityInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public CityInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public CityInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar una ciudad.
     * @param db, base de datos donde se buscara la ciudad.
     * @param cod, identificador de la ciudad a buscar.
     * @return ciudad, registro de la ciudad buscada.
     */
    public Ciudad searchCity(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_CIUDAD_ID,
                ConstantsDatabase.TABLE_CIUDAD_NOMBRE, ConstantsDatabase.TABLE_CIUDAD_DEPARTMENTO_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_CIUDAD, ConstantsDatabase.TABLE_CIUDAD_ID, fields, parameters);

        Ciudad ciudad = new Ciudad();

        if (cursor.moveToFirst()) {
            ciudad.setIdCiudad(cursor.getInt(0));
            ciudad.setNombre(cursor.getString(1));
            ciudad.setIdDepartamentoFK(cursor.getInt(2));
        }

        return ciudad;
    }

    /**
     * Método que permite insertar una ciudad.
     * @param db, base de datos en la cual se insertara la ciudad.
     * @param ciudad, ciudad a insertar en la base de datos.
     */
    public void insertCity(DataBase db, Ciudad ciudad) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_CIUDAD_ID, ciudad.getIdCiudad());
        contentValues.put(ConstantsDatabase.TABLE_CIUDAD_NOMBRE, ciudad.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_CIUDAD_DEPARTMENTO_FK, ciudad.getIdDepartamentoFK());

        db.insertRecord(ConstantsDatabase.TABLE_CIUDAD, contentValues);
    }

    /**
     * Método que permite modificar el registro de una ciudad.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param ciudad, ciudad a la cual se le modificaran los datos.
     */
    public void modifyCity(DataBase db, Ciudad ciudad) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_CIUDAD_ID, ciudad.getIdCiudad());
        contentValues.put(ConstantsDatabase.TABLE_CIUDAD_NOMBRE, ciudad.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_CIUDAD_DEPARTMENTO_FK, ciudad.getIdDepartamentoFK());

        db.editRecord(ConstantsDatabase.TABLE_CIUDAD, contentValues, ConstantsDatabase.TABLE_CIUDAD_ID, ciudad.getIdCiudad()+"");
    }

    /**
     * Método que permite eliminar una ciudad.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteCity(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_CIUDAD, ConstantsDatabase.TABLE_CIUDAD_ID, id+"");
    }

    /**
     * Método que permite obtener todas las ciudades.
     * @param db, base de datos donde se encuentran los registros.
     * @return ciudades, lista de las ciudades registradas.
     */
    public ArrayList<Ciudad> getCities(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_CIUDAD);
        ArrayList<Ciudad> ciudades = new ArrayList<>();

        while (registros.moveToNext()) {
            Ciudad ciudad = new Ciudad();
            ciudad.setIdCiudad(registros.getInt(0));
            ciudad.setNombre(registros.getString(1));
            ciudad.setIdDepartamentoFK(registros.getInt(1));
            ciudades.add(ciudad);
        }

        return ciudades;
    }
}
