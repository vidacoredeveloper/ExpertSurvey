package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Persona {

    /**
     * Atributos de la clase
     */
    private String documento;
    private int idTipoDocumentoFK;
    private String nombres;
    private String primerApellido;
    private String segundoApellido;
    private String estadoCivil;

    /**
     * Método constructor por default de la clase.
     */
    public Persona() {
    }

    /**
     * Método constructor de la clase.
     * @param documento, identificación de la persona.
     * @param idTipoDocumentoFK, tipo de identificación de la persona.
     * @param nombres, nombres de la persona.
     * @param primerApellido, primer apellido de la persona.
     * @param segundoApellido, segundo apellido de la persona.
     * @param estadoCivil, estado civil de la persona.
     */
    public Persona(String documento, int idTipoDocumentoFK, String nombres, String primerApellido,
                   String segundoApellido, String estadoCivil) {
        this.documento = documento;
        this.idTipoDocumentoFK = idTipoDocumentoFK;
        this.nombres = nombres;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.estadoCivil = estadoCivil;
    }

    /**
     * Método accesor del atributo documento.
     * @return documento, valor del atributo establecido.
     */
    public String getDocumento() {
        return documento;
    }

    /**
     * Método modificador correspondiente al valor del atributo documento.
     * @param documento, valor que se va a establecer en el atributo.
     */
    public void setDocumento(String documento) {
        this.documento = documento;
    }

    /**
     * Método accesor del atributo idTipoDocumentoFK.
     * @return idTipoDocumentoFK, valor del atributo establecido.
     */
    public int getIdTipoDocumentoFK() {
        return idTipoDocumentoFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idTipoDocumentoFK.
     * @param idTipoDocumentoFK, valor que se va a establecer en el atributo.
     */
    public void setIdTipoDocumentoFK(int idTipoDocumentoFK) {
        this.idTipoDocumentoFK = idTipoDocumentoFK;
    }

    /**
     * Método accesor del atributo nombres.
     * @return nombres, valor del atributo establecido.
     */
    public String getNombres() {
        return nombres;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombres.
     * @param nombres, valor que se va a establecer en el atributo.
     */
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    /**
     * Método accesor del atributo primerApellido.
     * @return primerApellido, valor del atributo establecido.
     */
    public String getPrimerApellido() {
        return primerApellido;
    }

    /**
     * Método modificador correspondiente al valor del atributo primerApellido.
     * @param primerApellido, valor que se va a establecer en el atributo.
     */
    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    /**
     * Método accesor del atributo segundoApellido.
     * @return segundoApellido, valor del atributo establecido.
     */
    public String getSegundoApellido() {
        return segundoApellido;
    }

    /**
     * Método modificador correspondiente al valor del atributo segundoApellido.
     * @param segundoApellido, valor que se va a establecer en el atributo.
     */
    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }

    /**
     * Método accesor del atributo estadoCivil.
     * @return estadoCivil, valor del atributo establecido.
     */
    public String getEstadoCivil() {
        return estadoCivil;
    }

    /**
     * Método modificador correspondiente al valor del atributo estadoCivil.
     * @param estadoCivil, valor que se va a establecer en el atributo.
     */
    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }
}
