package com.coursera.expertsurvey;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;

import com.coursera.expertsurvey.adapters.ListAdapterSurvey;
import com.coursera.expertsurvey.pojo.DummyData;
import com.coursera.expertsurvey.pojo.Encuesta;
import com.coursera.expertsurvey.pojo.Opcion;
import com.coursera.expertsurvey.pojo.Persona;
import com.coursera.expertsurvey.pojo.Pregunta;
import com.coursera.expertsurvey.pojo.Respuesta;
import com.coursera.expertsurvey.presenters.interfaces.IMainActivityPresenter;
import com.coursera.expertsurvey.presenters.MainActivityPresenter;
import com.coursera.expertsurvey.viewmodel.IMainActivityView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements IMainActivityView {

    /**
     * Componentes de la vista.
     */
    private Typeface streh;

    private RecyclerView rvSurveyAM;
    private IMainActivityPresenter presenter;
    private DummyData dummyData;

    private SharedPreferences preferences;

    public static Encuesta encuesta;
    public static Persona persona;
    public static Opcion opcionRespondida;
    public static ArrayList<Opcion> opcionesRespondidas;
    public static ArrayList<Pregunta> preguntas;
    private ArrayList<Respuesta> respuestas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeComponents();
    }

    /**
     * Método que inicializa los componentes gráficos y lógicos que pertenecen a la vista.
     */
    @Override
    public void initializeComponents() {
        encuesta = new Encuesta();
        persona = new Persona();
        preguntas = new ArrayList<>();
        respuestas = new ArrayList<>();
        opcionRespondida = new Opcion();
        opcionesRespondidas = new ArrayList<>();

        preferences = getSharedPreferences("MisPreferencias", Context.MODE_PRIVATE);
        verifyDummyData();
        streh = Typeface.createFromAsset(getAssets(), "fonts/STREH.TTF");

        rvSurveyAM = (RecyclerView) findViewById(R.id.rvSurveyAM);
        setLayoutRecyclerView();

        presenter = new MainActivityPresenter(this, getBaseContext());
    }

    /**
     * Método que permite editar el shared.
     */
    @Override
    public void editShared() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("key", "uno");
        editor.commit();
    }

    /**
     * Método que permite verificar la carga de los datos de prueba.
     */
    @Override
    public void verifyDummyData() {
        String key = preferences.getString("key", "paila");

        if(!key.equals("uno")){
            dummyData = new DummyData(getBaseContext());
            editShared();
        }
    }

    /**
     * Método que permite la asignacion de la organización y orientación de los elementos
     * en le recycler view.
     */
    @Override
    public void setLayoutRecyclerView() {
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        rvSurveyAM.setLayoutManager(llm);
    }

    /**
     * Método que permite generar el adaptador de la lista de las encuestas.
     */
    @Override
    public ListAdapterSurvey initializeListAdapterSurvey(ArrayList<Encuesta> encuestas) {
        return new ListAdapterSurvey(encuestas, this);
    }

    /**
     * Método que permite la inicialización del adaptador del recycler view.
     */
    @Override
    public void initializeAdapterRecyclerView(ListAdapterSurvey listAdapterSurvey) {
        rvSurveyAM.setAdapter(listAdapterSurvey);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK){
            Intent intent = new Intent(MainActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
