package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Pregunta {

    /**
     * Atributos de la clase.
     */
    private int idPregunta;
    private int numeroEncuestaFK;
    private String texto;
    private int tipoRespuestaFK;

    /**
     * Método constructor por default de la clase.
     */
    public Pregunta() {
    }

    /**
     * Método constructor de la clase.
     * @param numeroEncuestaFK
     * @param texto
     * @param tipoRespuestaFK
     */
    public Pregunta(int numeroEncuestaFK, String texto, int tipoRespuestaFK) {
        this.numeroEncuestaFK = numeroEncuestaFK;
        this.texto = texto;
        this.tipoRespuestaFK = tipoRespuestaFK;
    }

    /**
     * Método accesor del atributo idPregunta.
     * @return idPregunta, valor del atributo establecido.
     */
    public int getIdPregunta() {
        return idPregunta;
    }

    /**
     * Método modificador correspondiente al valor del atributo idPregunta.
     * @param idPregunta, valor que se va a establecer en el atributo.
     */
    public void setIdPregunta(int idPregunta) {
        this.idPregunta = idPregunta;
    }

    /**
     * Método accesor del atributo numeroEncuestaFK.
     * @return numeroEncuestaFK, valor del atributo establecido.
     */
    public int getNumeroEncuestaFK() {
        return numeroEncuestaFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo numeroEncuestaFK.
     * @param numeroEncuestaFK, valor que se va a establecer en el atributo.
     */
    public void setNumeroEncuestaFK(int numeroEncuestaFK) {
        this.numeroEncuestaFK = numeroEncuestaFK;
    }

    /**
     * Método accesor del atributo texto.
     * @return texto, valor del atributo establecido.
     */
    public String getTexto() {
        return texto;
    }

    /**
     * Método modificador correspondiente al valor del atributo texto.
     * @param texto, valor que se va a establecer en el atributo.
     */
    public void setTexto(String texto) {
        this.texto = texto;
    }

    /**
     * Método accesor del atributo tipoRespuestaFK.
     * @return tipoRespuestaFK, valor del atributo establecido.
     */
    public int getTipoRespuestaFK() {
        return tipoRespuestaFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo tipoRespuestaFK.
     * @param tipoRespuestaFK, valor que se va a establecer en el atributo.
     */
    public void setTipoRespuestaFK(int tipoRespuestaFK) {
        this.tipoRespuestaFK = tipoRespuestaFK;
    }
}
