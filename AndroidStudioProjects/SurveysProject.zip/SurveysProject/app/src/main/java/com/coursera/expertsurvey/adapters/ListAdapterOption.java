package com.coursera.expertsurvey.adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.coursera.expertsurvey.R;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.database.interactors.OptionInteractor;
import com.coursera.expertsurvey.pojo.Opcion;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 20/12/16.
 */

public class ListAdapterOption extends RecyclerView.Adapter<ListAdapterOption.ListAdapterOptionViewHolder> {

    /**
     * Atributos de la clase.
     */
    private Activity activity;
    private DataBase dataBase;
    private ArrayList<Opcion> opciones;
    private RadioGroup rbgOptionsAS;
    private OptionInteractor optionInteractor;

    /**
     * Método constructor de la clase.
     * @param activity, actividad en la que se encuentra el recycler.
     * @param dataBase, base de datos de la aplicación.
     * @param opciones, lista de opciones.
     */
    public ListAdapterOption(Activity activity, DataBase dataBase, ArrayList<Opcion> opciones, RadioGroup rbgOptionsAS) {
        this.activity = activity;
        this.dataBase = dataBase;
        this.opciones = opciones;
        this.rbgOptionsAS = rbgOptionsAS;
        optionInteractor = new OptionInteractor();
    }

    /**
     * Método que permite inflar el layout pasandolo al view holder para realizar el uso de los views.
     * @param parent, grupo de views a los cuales se realizará la inflación.
     * @param viewType, tipo de la view a la que se le realizará la inflación.
     * @return
     */
    @Override
    public ListAdapterOptionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.option_card_view, parent, false);
        return new ListAdapterOptionViewHolder(view);
    }

    /**
     * Método que realiza la asociación de cada elemento de a los view de la vista.
     * @param listAdapterOptionViewHolder, view al cual se le realizará la asociación de los elementos.
     * @param position, posicion del elemnto que se va asociar en la lista.
     */
    @Override
    public void onBindViewHolder(ListAdapterOptionViewHolder listAdapterOptionViewHolder, int position) {
        Opcion opcion = opciones.get(position);
        listAdapterOptionViewHolder.tvOptionOCV.setText(opcion.getEtiqueta());
        rbgOptionsAS.addView(listAdapterOptionViewHolder.rbTypeContactOCV);
    }

    /**
     * Método que permite conocer la cantidad de elementos de la lista.
     * @return size, cantidad de elementos de la lista.
     */
    @Override
    public int getItemCount() {
        return opciones.size();
    }

    /**
     * Clase statica que permite la interacción entre los objetos y las views.
     */
    public static class ListAdapterOptionViewHolder extends RecyclerView.ViewHolder {

        /**
         * Views de la vista.
         */
        private LinearLayout llOptionCardOCV;
        private TextView tvOptionOCV;
        private RadioButton rbTypeContactOCV;

        /**
         * Método constructor de la clase.
         * @param itemView, vista a la cual pertenecen los elementos.
         */
        public ListAdapterOptionViewHolder(View itemView) {
            super(itemView);
            llOptionCardOCV = (LinearLayout) itemView.findViewById(R.id.llOptionCardOCV);
            tvOptionOCV = (TextView) itemView.findViewById(R.id.tvOptionOCV);
            rbTypeContactOCV = (RadioButton) itemView.findViewById(R.id.rbTypeContactOCV);
        }
    }

    /**
     * Método que permite agregar el escuchador a los checkbox
     * @param checkBox, componente al que se le agregara el escuchador.
     */
    public void addListenerCheck(CheckBox checkBox, final Opcion opcion){
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                //MainActivity.opciones.add(opcion);
            }
        });
    }
}
