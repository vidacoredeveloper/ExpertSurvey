package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Departamento;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class DepartmentInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public DepartmentInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public DepartmentInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar un departamento.
     * @param db, base de datos donde se buscara el departamento.
     * @param cod, identificador del pais a buscar.
     * @return departamento, registro del departamento buscado.
     */
    public Departamento searchDepartment(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_DEPARTAMENTO_ID,
                ConstantsDatabase.TABLE_DEPARTAMENTO_NOMBRE, ConstantsDatabase.TABLE_DEPARTAMENTO_REGION_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_DEPARTAMENTO,
                ConstantsDatabase.TABLE_DEPARTAMENTO_ID, fields, parameters);

        Departamento departamento = new Departamento();

        if (cursor.moveToFirst()) {
            departamento.setIdDepartamento(cursor.getInt(0));
            departamento.setNombre(cursor.getString(1));
            departamento.setIdRegionFK(cursor.getInt(2));
        }

        return departamento;
    }

    /**
     * Método que permite insertar un departamento.
     * @param db, base de datos en la cual se insertara el departamento.
     * @param departamento, departamento a insertar en la base de datos.
     */
    public void insertDepartment(DataBase db, Departamento departamento) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_DEPARTAMENTO_ID, departamento.getIdDepartamento());
        contentValues.put(ConstantsDatabase.TABLE_DEPARTAMENTO_NOMBRE, departamento.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_DEPARTAMENTO_REGION_FK, departamento.getIdRegionFK());

        db.insertRecord(ConstantsDatabase.TABLE_DEPARTAMENTO, contentValues);
    }

    /**
     * Método que permite modificar el registro de un departamento.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param departamento, departamento a la cual se le modificaran los datos.
     */
    public void modifyDepartment(DataBase db, Departamento departamento) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_DEPARTAMENTO_ID, departamento.getIdDepartamento());
        contentValues.put(ConstantsDatabase.TABLE_DEPARTAMENTO_NOMBRE, departamento.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_DEPARTAMENTO_REGION_FK, departamento.getIdRegionFK());

        db.editRecord(ConstantsDatabase.TABLE_DEPARTAMENTO, contentValues, ConstantsDatabase.TABLE_DEPARTAMENTO_ID,
                departamento.getIdDepartamento()+"");
    }

    /**
     * Método que permite eliminar un departamento.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteDepartment(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_DEPARTAMENTO, ConstantsDatabase.TABLE_DEPARTAMENTO_ID, id+"");
    }

    /**
     * Método que permite obtener todos los departamentos.
     * @param db, base de datos donde se encuentran los registros.
     * @return departamentos, lista de los departamentos registrados.
     */
    public ArrayList<Departamento> getDepartments(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_DEPARTAMENTO);
        ArrayList<Departamento> departamentos = new ArrayList<>();

        while (registros.moveToNext()) {
            Departamento departamento = new Departamento();
            departamento.setIdDepartamento(registros.getInt(0));
            departamento.setNombre(registros.getString(1));
            departamento.setIdRegionFK(registros.getInt(2));
            departamentos.add(departamento);
        }

        return departamentos;
    }
}
