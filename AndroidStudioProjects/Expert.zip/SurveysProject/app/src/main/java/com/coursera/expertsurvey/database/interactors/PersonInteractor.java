package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Persona;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class PersonInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public PersonInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public PersonInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar una persona.
     * @param db, base de datos donde se buscara la persona.
     * @param cod, identificador de la persona a buscar.
     * @param doc, documento de la persona a buscar.
     * @return persona, registro de la persona buscada.
     */
    public Persona searchPerson(DataBase db, int cod, String doc) {

        Cursor cursor = db.searchRecordCompositeKey(ConstantsDatabase.TABLE_PERSONA, cod + "", doc,
                ConstantsDatabase.TABLE_PERSONA_TIPO_DOCUMENTO_FK, ConstantsDatabase.TABLE_PERSONA_DOCUMENTO);

        if(cursor != null) {
            Persona persona = new Persona();
            if(cursor.moveToFirst()){

                persona.setIdTipoDocumentoFK(cursor.getInt(0));
                persona.setDocumento(cursor.getString(1));
                persona.setNombres(cursor.getString(2));
                persona.setPrimerApellido(cursor.getString(3));
                persona.setSegundoApellido(cursor.getString(4));
                persona.setEstadoCivil(cursor.getString(5));

                db.close();
                cursor.close();
            }
            return persona;
        }
        else {
            db.close();
            cursor.close();
            return null;
        }
    }

    /**
     * Método que permite insertar una persona.
     * @param db, base de datos en la cual se insertara la persona.
     * @param persona, persona a insertar en la base de datos.
     */
    public void insertPerson(DataBase db, Persona persona) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_TIPO_DOCUMENTO_FK, persona.getIdTipoDocumentoFK());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_DOCUMENTO, persona.getDocumento());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_NOMBRES, persona.getNombres());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_PRIMER_APELLIDO, persona.getPrimerApellido());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_SEGUNDO_APELLIDO, persona.getSegundoApellido());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ESTADO_CIVIL, persona.getEstadoCivil());

        db.insertRecord(ConstantsDatabase.TABLE_PERSONA, contentValues);
    }

    /**
     * Método que permite modificar el registro de una persona.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param persona, persona a la cual se le modificaran los datos.
     */
    public void modifyPerson(DataBase db, Persona persona) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_TIPO_DOCUMENTO_FK, persona.getIdTipoDocumentoFK());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_DOCUMENTO, persona.getDocumento());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_NOMBRES, persona.getNombres());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_PRIMER_APELLIDO, persona.getPrimerApellido());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_SEGUNDO_APELLIDO, persona.getSegundoApellido());
        contentValues.put(ConstantsDatabase.TABLE_PERSONA_ESTADO_CIVIL, persona.getEstadoCivil());

        db.editRecordCompositeKey(ConstantsDatabase.TABLE_PERSONA, contentValues,
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_TIPO_DOCUMENTO_FK, persona.getIdTipoDocumentoFK()+"",
                ConstantsDatabase.TABLE_PERSONA_DOCUMENTO, persona.getDocumento());
    }



    /**
     * Método que permite eliminar una persona.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param idTipo, identificador del tipo del documento del registro a eliminar.
     * @param documento, documento del registro a eliminar.
     */
    public void deletePerson(DataBase db, int idTipo, String documento) {
        db.deleteRecordCompositeKey(ConstantsDatabase.TABLE_PERSONA,
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_TIPO_DOCUMENTO_FK, idTipo+"",
                ConstantsDatabase.TABLE_PERSONA_DOCUMENTO, documento);
    }

    /**
     * Método que permite obtener todas las personas.
     * @param db, base de datos donde se encuentran los registros.
     * @return personas, lista de las personas registradas.
     */
    public ArrayList<Persona> getPerson(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_PERSONA);
        ArrayList<Persona> personas = new ArrayList<>();

        while (registros.moveToNext()) {
            Persona persona = new Persona();
            persona.setIdTipoDocumentoFK(registros.getInt(0));
            persona.setDocumento(registros.getString(1));
            persona.setNombres(registros.getString(2));
            persona.setPrimerApellido(registros.getString(3));
            persona.setSegundoApellido(registros.getString(4));
            persona.setEstadoCivil(registros.getString(5));
            personas.add(persona);
        }

        return personas;
    }
}
