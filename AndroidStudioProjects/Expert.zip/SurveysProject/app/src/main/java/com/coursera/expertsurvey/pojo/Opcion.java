package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Opcion {

    /**
     * Atributos de la clase.
     */
    private int idOpcion;
    private String etiqueta;
    private boolean estado;
    private int valor;
    private int idPreguntaFK;

    /**
     * Método constructor por default de la clase.
     */
    public Opcion() {
    }

    /**
     * Método constructor de la clase.
     * @param etiqueta, texto de la opción.
     * @param valor, peso de la opción.
     * @param idPreguntaFK, identificador de la pregunta a la cual corresponde la opción.
     */
    public Opcion(String etiqueta, int valor, int idPreguntaFK) {
        this.etiqueta = etiqueta;
        estado = true;
        this.valor = valor;
        this.idPreguntaFK = idPreguntaFK;
    }

    /**
     * Método accesor del atributo idOpcion.
     * @return idOpcion, valor del atributo establecido.
     */
    public int getIdOpcion() {
        return idOpcion;
    }

    /**
     * Método modificador correspondiente al valor del atributo idOpcion.
     * @param idOpcion, valor que se va a establecer en el atributo.
     */
    public void setIdOpcion(int idOpcion) {
        this.idOpcion = idOpcion;
    }

    /**
     * Método accesor del atributo etiqueta.
     * @return etiqueta, valor del atributo establecido.
     */
    public String getEtiqueta() {
        return etiqueta;
    }

    /**
     * Método modificador correspondiente al valor del atributo etiqueta.
     * @param etiqueta, valor que se va a establecer en el atributo.
     */
    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    /**
     * Método accesor del atributo estado.
     * @return estado, valor del atributo establecido.
     */
    public boolean isEstado() {
        return estado;
    }

    /**
     * Método modificador correspondiente al valor del atributo estado.
     * @param estado, valor que se va a establecer en el atributo.
     */
    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    /**
     * Método accesor del atributo valor.
     * @return valor, valor del atributo establecido.
     */
    public int getValor() {
        return valor;
    }

    /**
     * Método modificador correspondiente al valor del atributo valor.
     * @param valor, valor que se va a establecer en el atributo.
     */
    public void setValor(int valor) {
        this.valor = valor;
    }

    /**
     * Método accesor del atributo idPreguntaFK.
     * @return idPreguntaFK, valor del atributo establecido.
     */
    public int getIdPreguntaFK() {
        return idPreguntaFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idPreguntaFK.
     * @param idPreguntaFK, valor que se va a establecer en el atributo.
     */
    public void setIdPreguntaFK(int idPreguntaFK) {
        this.idPreguntaFK = idPreguntaFK;
    }
}

