package com.coursera.expertsurvey.presenters.interfaces;

import android.widget.ArrayAdapter;

import com.coursera.expertsurvey.pojo.Persona;

/**
 * Created by Victor Daniel Cortés Restrepo on 19/12/16.
 */

public interface IProfileActivityPresenter {

    /**
     * Método que permite buscar una persona.
     * @param type, tipo de documento por el cual se realizará la búsqueda de la persona.
     * @param document, documento por el cual se realizará la búsqueda de la persona.
     */
    public Persona searchPerson(int type, String document);

    /**
     * Método que permite obtener los tipos de documento.
     * @return lista de los tipos de documento registrados.
     */
    public ArrayAdapter getTypeDocument();

    /**
     * Método que permite extraer los contactos de la base de datos según la persona.
     * @param type, tipo de documento por el cual se realizará la búsqueda de los contactos de la persona.
     * @param document, documento por el cual se realizará la búsqueda de los contactos de la persona.
     */
    public void getContactsPerson(int type, String document);

    /**
     * Método que permite mostrar los contactos en la vista.
     */
    public void showContactsReclyclerView();
}
