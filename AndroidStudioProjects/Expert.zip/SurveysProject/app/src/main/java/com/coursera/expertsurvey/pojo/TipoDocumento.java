package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class TipoDocumento {

    /**
     * Atributos de la clase.
     */
    private int idTipoDocumento;
    private String nombre;
    private String descripcion;
    private String abreviatura;

    /**
     * Método constructor por default de la clase.
     */
    public TipoDocumento() {
    }

    /**
     * Método constructor de la clase.
     * @param nombre, nombre del tipo de documento.
     * @param descripcion, descripcion del tipo de documento.
     * @param abreviatura, siglase correspondientes al tipo de documento.
     */
    public TipoDocumento(String nombre, String descripcion, String abreviatura) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.abreviatura = abreviatura;
    }

    /**
     * Método accesor del atributo idPregunta.
     * @return idPregunta, valor del atributo establecido.
     */
    public int getIdTipoDocumento() {
        return idTipoDocumento;
    }

    /**
     * Método modificador correspondiente al valor del atributo idTipoDocumento.
     * @param idTipoDocumento, valor que se va a establecer en el atributo.
     */
    public void setIdTipoDocumento(int idTipoDocumento) {
        this.idTipoDocumento = idTipoDocumento;
    }

    /**
     * Método accesor del atributo nombre.
     * @return nombre, valor del atributo establecido.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombre.
     * @param nombre, valor que se va a establecer en el atributo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método accesor del atributo descripcion.
     * @return descripcion, valor del atributo establecido.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Método modificador correspondiente al valor del atributo descripcion.
     * @param descripcion, valor que se va a establecer en el atributo.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Método accesor del atributo abreviatura.
     * @return abreviatura, valor del atributo establecido.
     */
    public String getAbreviatura() {
        return abreviatura;
    }

    /**
     * Método modificador correspondiente al valor del atributo abreviatura.
     * @param abreviatura, valor que se va a establecer en el atributo.
     */
    public void setAbreviatura(String abreviatura) {
        this.abreviatura = abreviatura;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
