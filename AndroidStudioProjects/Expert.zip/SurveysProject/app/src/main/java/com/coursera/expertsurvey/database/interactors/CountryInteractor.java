package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Pais;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class CountryInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public CountryInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public CountryInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar un pais.
     * @param db, base de datos donde se buscara el pais.
     * @param cod, identificador del pais a buscar.
     * @return pais, registro del pais buscado.
     */
    public Pais searchCountry(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_PAIS_ID,
                ConstantsDatabase.TABLE_PAIS_NOMBRE, ConstantsDatabase.TABLE_PAIS_CONTINENTE_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_PAIS,
                ConstantsDatabase.TABLE_PAIS_ID, fields, parameters);

        Pais pais = new Pais();

        if (cursor.moveToFirst()) {
            pais.setIdPais(cursor.getInt(0));
            pais.setNombre(cursor.getString(1));
            pais.setIdContinenteFK(cursor.getInt(2));
        }

        return pais;
    }

    /**
     * Método que permite insertar un pais.
     * @param db, base de datos en la cual se insertara el pais.
     * @param pais, pais a insertar en la base de datos.
     */
    public void insertCountry(DataBase db, Pais pais) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_PAIS_ID, pais.getIdPais());
        contentValues.put(ConstantsDatabase.TABLE_PAIS_NOMBRE, pais.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_PAIS_CONTINENTE_FK, pais.getIdContinenteFK());

        db.insertRecord(ConstantsDatabase.TABLE_PAIS, contentValues);
    }

    /**
     * Método que permite modificar el registro de un pais.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param pais, pais a la cual se le modificaran los datos.
     */
    public void modifyCountry(DataBase db, Pais pais) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_PAIS_ID, pais.getIdPais());
        contentValues.put(ConstantsDatabase.TABLE_PAIS_NOMBRE, pais.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_PAIS_CONTINENTE_FK, pais.getIdContinenteFK());

        db.editRecord(ConstantsDatabase.TABLE_PAIS, contentValues, ConstantsDatabase.TABLE_PAIS_ID,
                pais.getIdPais()+"");
    }

    /**
     * Método que permite eliminar un pais.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteCountry(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_PAIS, ConstantsDatabase.TABLE_PAIS_ID, id+"");
    }

    /**
     * Método que permite obtener todos los paises.
     * @param db, base de datos donde se encuentran los registros.
     * @return paises, lista de los paises registrados.
     */
    public ArrayList<Pais> getCountries(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_PAIS);
        ArrayList<Pais> paises = new ArrayList<>();

        while (registros.moveToNext()) {
            Pais pais = new Pais();
            pais.setIdPais(registros.getInt(0));
            pais.setNombre(registros.getString(1));
            pais.setIdContinenteFK(registros.getInt(2));
            paises.add(pais);
        }

        return paises;
    }
}
