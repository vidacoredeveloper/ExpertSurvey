package com.coursera.expertsurvey.pojo;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Encuesta {

    /**
     * Atributos de la clase.
     */
    private int numero;
    private Date fechaCreacion;
    private String nombre;
    private int cantidadPreguntas;
    private boolean vigente;

    /**
     * Método constructor por default de la clase.
     */
    public Encuesta() {
    }

    /**
     * Método constructor de la clase.
     * @param nombre, nombre de la encuesta.
     * @param cantidadPreguntas, cantidad de preguntas que contiene la encuesta.
     */
    public Encuesta(String nombre, int cantidadPreguntas) {
        fechaCreacion = Calendar.getInstance().getTime();
        this.nombre = nombre;
        this.cantidadPreguntas = cantidadPreguntas;
        vigente = true;
    }

    /**
     * Método accesor del atributo fechaCreacion.
     * @return fechaCreacion, valor del atributo establecido.
     */
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    /**
     * Método modificador correspondiente al valor del atributo fechaCreacion.
     * @param fechaCreacion, valor que se va a establecer en el atributo.
     */
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    /**
     * Método accesor del atributo nombre.
     * @return nombre, valor del atributo establecido.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombre.
     * @param nombre, valor que se va a establecer en el atributo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método accesor del atributo cantidadPreguntas.
     * @return cantidadPreguntas, valor del atributo establecido.
     */
    public int getCantidadPreguntas() {
        return cantidadPreguntas;
    }

    /**
     * Método modificador correspondiente al valor del atributo cantidadPreguntas.
     * @param cantidadPreguntas, valor que se va a establecer en el atributo.
     */
    public void setCantidadPreguntas(int cantidadPreguntas) {
        this.cantidadPreguntas = cantidadPreguntas;
    }

    /**
     * Método accesor del atributo vigente.
     * @return vigente, valor del atributo establecido.
     */
    public boolean isVigente() {
        return vigente;
    }

    /**
     * Método modificador correspondiente al valor del atributo vigente.
     * @param vigente, valor que se va a establecer en el atributo.
     */
    public void setVigente(boolean vigente) {
        this.vigente = vigente;
    }

    /**
     * Método accesor del atributo numero.
     * @return numero, valor del atributo establecido.
     */
    public int getNumero() {
        return numero;
    }

    /**
     * Método modificador correspondiente al valor del atributo numero.
     * @param numero, valor que se va a establecer en el atributo.
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }
}
