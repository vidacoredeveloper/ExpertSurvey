package com.coursera.expertsurvey.pojo;

import android.content.Context;

import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.database.interactors.ContactInteractor;
import com.coursera.expertsurvey.database.interactors.OptionInteractor;
import com.coursera.expertsurvey.database.interactors.PersonInteractor;
import com.coursera.expertsurvey.database.interactors.QuestionInteractor;
import com.coursera.expertsurvey.database.interactors.SurveyInteractor;
import com.coursera.expertsurvey.database.interactors.TypeContactInteractor;
import com.coursera.expertsurvey.database.interactors.TypeDocumentInteractor;
import com.coursera.expertsurvey.database.interactors.TypeResponseInteractor;

import java.util.Calendar;

/**
 * Created by Victor Daniel Cortés Restrepo on 20/12/16.
 */

public class DummyData {

    private Context context;
    private SurveyInteractor surveyInteractor;
    private PersonInteractor personInteractor;
    private OptionInteractor optionInteractor;
    private ContactInteractor contactInteractor;
    private QuestionInteractor questionInteractor;
    private TypeContactInteractor typeContactInteractor;
    private TypeResponseInteractor typeResponseInteractor;
    private TypeDocumentInteractor typeDocumentInteractor;

    public DummyData(Context context) {
        this.context = context;
        surveyInteractor = new SurveyInteractor(context);
        personInteractor = new PersonInteractor(context);
        optionInteractor = new OptionInteractor(context);
        contactInteractor = new ContactInteractor(context);
        questionInteractor = new QuestionInteractor(context);
        typeContactInteractor = new TypeContactInteractor(context);
        typeResponseInteractor = new TypeResponseInteractor(context);
        typeDocumentInteractor = new TypeDocumentInteractor(context);
        insertarTiposRespuesta();
        insertarTiposContacto();
        insertarTiposDocumento();
        insertarEncuestas();
    }

    private void insertarTiposRespuesta(){
        DataBase dataBase = new DataBase(context);

        TipoRespuesta tipoRespuesta1 = new TipoRespuesta();
        tipoRespuesta1.setNombre("Unica");
        tipoRespuesta1.setDescripcion("");

        typeResponseInteractor.insertTypeResponse(dataBase, tipoRespuesta1);

        TipoRespuesta tipoRespuesta2 = new TipoRespuesta();
        tipoRespuesta2.setNombre("Mutiple");
        tipoRespuesta2.setDescripcion("");

        typeResponseInteractor.insertTypeResponse(dataBase, tipoRespuesta2);
    }

    private void insertarEncuestas(){
        DataBase dataBase = new DataBase(context);

        Encuesta e1 = new Encuesta();
        e1.setNombre("Encuesta de Clima Laboral");
        e1.setCantidadPreguntas(2);
        e1.setVigente(true);
        e1.setFechaCreacion(Calendar.getInstance().getTime());

        surveyInteractor.insertSurveys(dataBase, e1);
        insertarPreguntasEncuesta(dataBase, 1, "POR LA MAÑANA CUANDO SE LEVANTA PARA VENIR AL TRABAJO, USTED SE SIENTE:", 1);

        insertarOpcionesPregunta(dataBase, 1, "Muy Feliz");
        insertarOpcionesPregunta(dataBase, 1, "Feliz");
        insertarOpcionesPregunta(dataBase, 1, "Ni feliz ni aburrido");
        insertarOpcionesPregunta(dataBase, 1, "Aburrido");
        insertarOpcionesPregunta(dataBase, 1, "Muy aburrido");

        insertarPreguntasEncuesta(dataBase, 1, "QUÉ ASPECTOS SON LOS MÁS IMPORTANTES EN EL TRABAJO PARA USTED?", 2);

        insertarOpcionesPregunta(dataBase, 2, "Buen salario");
        insertarOpcionesPregunta(dataBase, 2, "Buen trato");
        insertarOpcionesPregunta(dataBase, 2, "Oportunidades de ascenso");
        insertarOpcionesPregunta(dataBase, 2, "Oportunidades de estudio");
    }

    private void insertarPreguntasEncuesta(DataBase dataBase,int id, String texto, int idTipo){
        Pregunta pregunta = new Pregunta();
        pregunta.setNumeroEncuestaFK(id);
        pregunta.setTexto(texto);
        pregunta.setTipoRespuestaFK(idTipo);

        questionInteractor.insertQuestion(dataBase, pregunta);
    }

    private void insertarOpcionesPregunta(DataBase dataBase, int idPregunta, String etiqueta) {
        Opcion opcion = new Opcion();
        opcion.setIdPreguntaFK(idPregunta);
        opcion.setValor(5);
        opcion.setEtiqueta(etiqueta);
        opcion.setEstado(true);

        optionInteractor.insertOption(dataBase, opcion);
    }

    private void insertarTiposDocumento(){
        DataBase dataBase = new DataBase(context);

        TipoDocumento tipoDocumento1 = new TipoDocumento();
        tipoDocumento1.setNombre("Cédula de ciudadanía");
        tipoDocumento1.setAbreviatura("CC");
        tipoDocumento1.setDescripcion("");

        typeDocumentInteractor.insertTypeDocument(dataBase, tipoDocumento1);

        TipoDocumento tipoDocumento2 = new TipoDocumento();
        tipoDocumento2.setNombre("Cédula de extranjería");
        tipoDocumento2.setAbreviatura("CE");
        tipoDocumento2.setDescripcion("");

        typeDocumentInteractor.insertTypeDocument(dataBase, tipoDocumento2);

        TipoDocumento tipoDocumento3 = new TipoDocumento();
        tipoDocumento3.setNombre("Tarjeta de identidad");
        tipoDocumento3.setAbreviatura("TI");
        tipoDocumento3.setDescripcion("");

        typeDocumentInteractor.insertTypeDocument(dataBase, tipoDocumento3);

        insertarPersonas();
    }

    private void insertarTiposContacto(){
        DataBase dataBase = new DataBase(context);

        TipoContacto tipoContacto1 = new TipoContacto();
        tipoContacto1.setNombre("Email");
        tipoContacto1.setDescripcion("");

        typeContactInteractor.insertTypeContact(dataBase, tipoContacto1);

        TipoContacto tipoContacto2 = new TipoContacto();
        tipoContacto2.setNombre("Celular");
        tipoContacto2.setDescripcion("");

        typeContactInteractor.insertTypeContact(dataBase, tipoContacto2);

        TipoContacto tipoContacto3 = new TipoContacto();
        tipoContacto3.setNombre("Telefono");
        tipoContacto3.setDescripcion("");

        typeContactInteractor.insertTypeContact(dataBase, tipoContacto3);
    }

    private void insertarPersonas(){
        DataBase dataBase = new DataBase(context);

        Persona persona1 = new Persona();
        persona1.setIdTipoDocumentoFK(1);
        persona1.setDocumento("52069137");
        persona1.setNombres("VICTOR DANIEL");
        persona1.setPrimerApellido("CORTÉS");
        persona1.setSegundoApellido("RESTREPO");
        persona1.setEstadoCivil("Soltero");

        personInteractor.insertPerson(dataBase, persona1);
        insertarContactosPersona(persona1, 1, "", "", "", "vimaco@gmail.com");
        insertarContactosPersona(persona1, 3, "4771579", "57", "6", "");

        Persona persona2 = new Persona();
        persona2.setIdTipoDocumentoFK(2);
        persona2.setDocumento("594372");
        persona2.setNombres("JUAN PABLO");
        persona2.setPrimerApellido("PEREIRA");
        persona2.setSegundoApellido("CASTAÑEDA");
        persona2.setEstadoCivil("Solter0");

        personInteractor.insertPerson(dataBase, persona2);
        insertarContactosPersona(persona2, 1, "", "", "", "pablosper@gmail.com");
    }

    private void insertarContactosPersona(Persona persona, int tipocontacto, String numTel, String codP,
                                        String codA, String email){
        DataBase dataBase = new DataBase(context);

        Contacto contacto = new Contacto();
        contacto.setIdTipoDocumentoFK(persona.getIdTipoDocumentoFK());
        contacto.setDocumentoFK(persona.getDocumento());
        contacto.setIdTipoContactoFK(tipocontacto);
        contacto.setNumeroTel(numTel);
        contacto.setCodAreaTel(codA);
        contacto.setCodPaisTel(codP);
        contacto.setEmail(email);

        contactInteractor.insertContact(dataBase, contacto);
    }
}
