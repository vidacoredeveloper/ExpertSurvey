package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Continente;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class ContinentInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public ContinentInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public ContinentInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar un continente.
     * @param db, base de datos donde se buscara el continente.
     * @param cod, identificador del continente a buscar.
     * @return continente, registro del continente buscado.
     */
    public Continente searchContinent(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_CONTINENTE_ID,
                ConstantsDatabase.TABLE_CONTINENTE_NOMBRE};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_CONTINENTE,
                ConstantsDatabase.TABLE_CONTINENTE_ID, fields, parameters);

        Continente continente = new Continente();

        if (cursor.moveToFirst()) {
            continente.setIdContinente(cursor.getInt(0));
            continente.setNombre(cursor.getString(1));
        }

        return continente;
    }

    /**
     * Método que permite insertar un continente.
     * @param db, base de datos en la cual se insertara el continente.
     * @param continente, continente a insertar en la base de datos.
     */
    public void insertContinent(DataBase db, Continente continente) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_CONTINENTE_ID, continente.getIdContinente());
        contentValues.put(ConstantsDatabase.TABLE_CONTINENTE_NOMBRE, continente.getNombre());

        db.insertRecord(ConstantsDatabase.TABLE_CONTINENTE, contentValues);
    }

    /**
     * Método que permite modificar el registro de un continente.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param continente, continente a la cual se le modificaran los datos.
     */
    public void modifyContinent(DataBase db, Continente continente) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_CONTINENTE_ID, continente.getIdContinente());
        contentValues.put(ConstantsDatabase.TABLE_CONTINENTE_NOMBRE, continente.getNombre());

        db.editRecord(ConstantsDatabase.TABLE_CONTINENTE, contentValues, ConstantsDatabase.TABLE_CONTINENTE_ID,
                continente.getIdContinente()+"");
    }

    /**
     * Método que permite eliminar un continente.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteContinent(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_CONTINENTE, ConstantsDatabase.TABLE_CONTINENTE_ID, id+"");
    }

    /**
     * Método que permite obtener todos los continentes.
     * @param db, base de datos donde se encuentran los registros.
     * @return continentes, lista de los continentes registrados.
     */
    public ArrayList<Continente> getContinents(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_CONTACTO);
        ArrayList<Continente> continentes = new ArrayList<>();

        while (registros.moveToNext()) {
            Continente continente = new Continente();
            continente.setIdContinente(registros.getInt(0));
            continente.setNombre(registros.getString(1));
            continentes.add(continente);
        }

        return continentes;
    }
}
