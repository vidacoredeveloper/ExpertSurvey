package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class TipoContacto {

    /**
     * Atributos de la clase.
     */
    private int idTipoContacto;
    private String nombre;
    private String descripcion;

    /**
     * Método constructor por default de la clase.
     */
    public TipoContacto() {
    }

    /**
     * Método constructor de la clase.
     * @param nombre, nombre del tipo de contacto.
     * @param descripcion, descripción del tipo de contacto.
     */
    public TipoContacto(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    /**
     * Método accesor del atributo idTipoContacto.
     * @return idTipoContacto, valor del atributo establecido.
     */
    public int getIdTipoContacto() {
        return idTipoContacto;
    }

    /**
     * Método modificador correspondiente al valor del atributo idTipoContacto.
     * @param idTipoContacto, valor que se va a establecer en el atributo.
     */
    public void setIdTipoContacto(int idTipoContacto) {
        this.idTipoContacto = idTipoContacto;
    }

    /**
     * Método accesor del atributo nombre.
     * @return nombre, valor del atributo establecido.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombre.
     * @param nombre, valor que se va a establecer en el atributo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método accesor del atributo descripcion.
     * @return descripcion, valor del atributo establecido.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Método modificador correspondiente al valor del atributo descripcion.
     * @param descripcion, valor que se va a establecer en el atributo.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
