package com.coursera.expertsurvey.viewmodel;

import android.view.View;
import android.widget.ArrayAdapter;

import com.coursera.expertsurvey.pojo.Opcion;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 20/12/16.
 */

public interface ISurveyActivityView {

    /**
     * Método que inicializa los componentes gráficos y lógicos que pertenecen a la vista.
     */
    public void initializeComponents();

    /**
     * Método que permite buscar los datos de una encuesta.
     */
    public void getSurvey();

    /**
     * Método que permite cargar la lista de preguntas.
     */
    public void loadListQuestions();

    /**
     * Método que permite cargar la lista de opciones.
     */
    public void loadListOptions();

    /**
     * Método que permite continuar con la siguiente pregunta de la encuesta.
     * @param view, vista desde la cual se hace el llamado del método.
     */
    public void nextQuestion(View view);

    /**
     * Método que permite la inicialización del adaptador del list view.
     * @param adapter, lista de los items que se mostraran en el list view.
     */
    public void initializeAdapterListView(ArrayAdapter adapter);

    /**
     * Método que permite guardar una persona encuesta.
     */
    public void savePersonSurvey();

    /**
     * Método que permite guardar las respuestas de la encuesta.
     */
    public void saveSurveyResponses();

    /**
     * Método que permite generar un escuchador a los items del list view.
     * @param opciones, lista de las opciones mostradas en el list view.
     */
    public void listItemListenerCombo(final ArrayList<Opcion> opciones);

    /**
     * Método que permite generar un escuchador a los items del list view.
     * @param opciones, lista de las opciones mostradas en el list view.
     */
    public void listItemListenerCheck(final ArrayList<Opcion> opciones);
}
