package com.coursera.expertsurvey.viewmodel;

import android.view.View;

import com.coursera.expertsurvey.adapters.ListAdapterContact;
import com.coursera.expertsurvey.pojo.Contacto;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 19/12/16.
 */

public interface IProfileActivityView {

    /**
     * Método que inicializa los componentes gráficos y lógicos que pertenecen a la vista.
     */
    public void initializeComponents();

    /**
     * Método que permite cargar una lista en un spinner.
     */
    public void loadSpinner();

    /**
     * Método que permite la asignacion de la organización y orientación de los elementos
     * en le recycler view.
     */
    public void setLayoutRecyclerView();

    /**
     * Método que permite generar el adaptador de la lista de los contactos.
     */
    public ListAdapterContact initializeListAdapterSurvey(ArrayList<Contacto> contactos);

    /**
     * Método que permite la inicialización del adaptador del recycler view.
     */
    public void initializeAdapterRecyclerView(ListAdapterContact listAdapterContact);

    /**
     * Método que permite obtener el teclado virtual del android.
     * @param view, vista desde la cual se ejecuta el método.
     */
    public void controlGraphicsComponents(View view);

    /**
     * Método que permite encontrar una persona.
     * @param view, vista desde la cual se ejecuta el método.
     */
    public void searchPerson(View view);

    /**
     * Método que permite iniciar con la encuesta.
     * @param view, vista desde la cual se ejecuta el método.
     */
    public void goSurvey(View view);

    /**
     * Método que permite eliminar el texto de los text views de los datos.
     */
    public void cleanDataFields();

    /**
     * Método que permite eliminar el texto de los text views del buscador.
     */
    public void cleanFieldsSearch();

    /**
     * Método que permite establecer el escuchador del spinner.
     */
    public void establishListenerSpinner();
}
