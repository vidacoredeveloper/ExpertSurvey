package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class TipoRespuesta {

    /**
     * Atributos de la clase.
     */
    private int idTipoRespuesta;
    private String nombre;
    private String descripcion;

    /**
     * Método constructor por default de la clase.
     */
    public TipoRespuesta() {
    }

    /**
     * Método contructor de la clase.
     * @param nombre, nombre perteneciente al tipo de respuesta.
     * @param descripcion, descripción correspondiente al tipo de respuesta.
     */
    public TipoRespuesta(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    /**
     * Método accesor del atributo idTipoRespuesta.
     * @return idTipoRespuesta, valor del atributo establecido.
     */
    public int getIdTipoRespuesta() {
        return idTipoRespuesta;
    }

    /**
     * Método modificador correspondiente al valor del atributo idTipoRespuesta.
     * @param idTipoRespuesta, valor que se va a establecer en el atributo.
     */
    public void setIdTipoRespuesta(int idTipoRespuesta) {
        this.idTipoRespuesta = idTipoRespuesta;
    }

    /**
     * Método accesor del atributo nombre.
     * @return nombre, valor del atributo establecido.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombre.
     * @param nombre, valor que se va a establecer en el atributo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método accesor del atributo descripcion.
     * @return descripcion, valor del atributo establecido.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Método modificador correspondiente al valor del atributo descripcion.
     * @param descripcion, valor que se va a establecer en el atributo.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
