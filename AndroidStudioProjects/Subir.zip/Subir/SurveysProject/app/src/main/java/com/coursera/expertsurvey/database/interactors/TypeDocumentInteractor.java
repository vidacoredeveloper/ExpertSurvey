package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.TipoDocumento;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class TypeDocumentInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public TypeDocumentInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public TypeDocumentInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar un tipo documento.
     * @param db, base de datos donde se buscara el tipo documento.
     * @param cod, identificador del tipo contacto a buscar.
     * @return tipoDocumento, registro del tipo documento buscado.
     */
    public TipoDocumento searchTypeDocument(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ID,
                ConstantsDatabase.TABLE_TIPO_DOCUMENTO_NOMBRE, ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ABREVIATURA,
                ConstantsDatabase.TABLE_TIPO_DOCUMENTO_DESCRIPCION};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_TIPO_DOCUMENTO,
                ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ID, fields, parameters);

        TipoDocumento tipoDocumento = new TipoDocumento();

        if (cursor.moveToFirst()) {
            tipoDocumento.setIdTipoDocumento(cursor.getInt(0));
            tipoDocumento.setNombre(cursor.getString(1));
            tipoDocumento.setAbreviatura(cursor.getString(2));
            tipoDocumento.setDescripcion(cursor.getString(3));
        }

        return tipoDocumento;
    }

    /**
     * Método que permite insertar un tipoDocumento.
     * @param db, base de datos en la cual se insertara el tipoDocumento.
     * @param tipoDocumento, tipoDocumento a insertar en la base de datos.
     */
    public void insertTypeDocument(DataBase db, TipoDocumento tipoDocumento) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_TIPO_DOCUMENTO_NOMBRE, tipoDocumento.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ABREVIATURA, tipoDocumento.getAbreviatura());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_DOCUMENTO_DESCRIPCION, tipoDocumento.getDescripcion());

        db.insertRecord(ConstantsDatabase.TABLE_TIPO_DOCUMENTO, contentValues);
    }

    /**
     * Método que permite modificar el registro de un tipoDocumento.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param tipoDocumento, tipoDocumento a la cual se le modificaran los datos.
     */
    public void modifyTypeDocument(DataBase db, TipoDocumento tipoDocumento) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ID, tipoDocumento.getIdTipoDocumento());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_DOCUMENTO_NOMBRE, tipoDocumento.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ABREVIATURA, tipoDocumento.getAbreviatura());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_DOCUMENTO_DESCRIPCION, tipoDocumento.getDescripcion());

        db.editRecord(ConstantsDatabase.TABLE_TIPO_DOCUMENTO, contentValues, ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ID,
                tipoDocumento.getIdTipoDocumento()+"");
    }

    /**
     * Método que permite eliminar un tipo documento.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteTypeDocument(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_TIPO_DOCUMENTO, ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ID, id+"");
    }

    /**
     * Método que permite obtener todos los tipos documento.
     * @param db, base de datos donde se encuentran los registros.
     * @return tiposDocumento, lista de los tipos documento registrados.
     */
    public ArrayList<TipoDocumento> getTypesDocument(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_TIPO_DOCUMENTO);
        ArrayList<TipoDocumento> tiposDocumento = new ArrayList<>();

        while (registros.moveToNext()) {
            TipoDocumento tipoDocumento = new TipoDocumento();
            tipoDocumento.setIdTipoDocumento(registros.getInt(0));
            tipoDocumento.setNombre(registros.getString(1));
            tipoDocumento.setAbreviatura(registros.getString(2));
            tipoDocumento.setDescripcion(registros.getString(3));
            tiposDocumento.add(tipoDocumento);
        }

        return tiposDocumento;
    }
}
