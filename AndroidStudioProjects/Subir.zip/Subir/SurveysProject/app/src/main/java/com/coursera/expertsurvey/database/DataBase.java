package com.coursera.expertsurvey.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Victor Daniel Cortés Restrepo on 13/12/16.
 */

public class DataBase extends SQLiteOpenHelper{

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista.
     */
    public DataBase(Context context) {
        super(context, ConstantsDatabase.DATABASE_NAME, null, ConstantsDatabase.DATABASE_VERSION);
        this.context = context;
    }

    /**
     * Método que permite generar la base de datos.
     * @param db, base de datos a generar.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        /**
         * Creación de la tabla Encuesta.
         */
        String queryCreateTableEncuesta = "CREATE TABLE " + ConstantsDatabase.TABLE_ENCUESTA + "(" +
                ConstantsDatabase.TABLE_ENCUESTA_NUMERO     + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_ENCUESTA_NOMBRE     + " TEXT, " +
                ConstantsDatabase.TABLE_ENCUESTA_FECHA      + " TEXT, " +
                ConstantsDatabase.TABLE_ENCUESTA_CANTIDAD   + " INTEGER, " +
                ConstantsDatabase.TABLE_ENCUESTA_VIGENCIA   + " NUMERIC" +
            ")";

        db.execSQL(queryCreateTableEncuesta);

        /**
         * Creación de la tabla Ciudad.
         */
        String queryCreateTableCiudad = "CREATE TABLE " + ConstantsDatabase.TABLE_CIUDAD + "(" +
                ConstantsDatabase.TABLE_CIUDAD_ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_CIUDAD_NOMBRE           + " TEXT, " +
                ConstantsDatabase.TABLE_CIUDAD_DEPARTMENTO_FK   + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_CIUDAD_DEPARTMENTO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_DEPARTAMENTO + "(" + ConstantsDatabase.TABLE_DEPARTAMENTO_ID + ")" +
                ")";

        db.execSQL(queryCreateTableCiudad);

        /**
         * Creación de la tabla Contacto.
         */
        String queryCreateTableContacto = "CREATE TABLE " + ConstantsDatabase.TABLE_CONTACTO + "(" +
                ConstantsDatabase.TABLE_CONTACTO_ID                 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_CONTACTO_EMAIL              + " TEXT, " +
                ConstantsDatabase.TABLE_CONTACTO_COD_PAIS_TEL       + " TEXT, " +
                ConstantsDatabase.TABLE_CONTACTO_COD_AREA_TEL       + " TEXT, " +
                ConstantsDatabase.TABLE_CONTACTO_NUM_TEL            + " TEXT, " +
                ConstantsDatabase.TABLE_CONTACTO_TIPO_CONTACTO_FK   + " INTEGER, " +
                ConstantsDatabase.TABLE_CONTACTO_DOCUMENTO_FK       + " TEXT, " +
                ConstantsDatabase.TABLE_CONTACTO_TIPO_DOCUMENTO_FK  + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_CONTACTO_TIPO_CONTACTO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_TIPO_CONTACTO + "(" + ConstantsDatabase.TABLE_TIPO_CONTACTO_ID + "), " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_CONTACTO_DOCUMENTO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_PERSONA + "(" + ConstantsDatabase.TABLE_PERSONA_DOCUMENTO + "), " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_CONTACTO_TIPO_DOCUMENTO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_PERSONA + "(" + ConstantsDatabase.TABLE_PERSONA_TIPO_DOCUMENTO_FK + ")" +
                ")";

        db.execSQL(queryCreateTableContacto);

        /**
         * Creación de la tabla Continente.
         */
        String queryCreateTableContinente = "CREATE TABLE " + ConstantsDatabase.TABLE_CONTINENTE + "(" +
                ConstantsDatabase.TABLE_CONTINENTE_ID       + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_CONTINENTE_NOMBRE   + " TEXT" +
                ")";

        db.execSQL(queryCreateTableContinente);

        /**
         * Creación de la tabla Departamento.
         */
        String queryCreateTableDepartamento = "CREATE TABLE " + ConstantsDatabase.TABLE_DEPARTAMENTO + "(" +
                ConstantsDatabase.TABLE_DEPARTAMENTO_ID         + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_DEPARTAMENTO_NOMBRE     + " TEXT, " +
                ConstantsDatabase.TABLE_DEPARTAMENTO_REGION_FK  + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_DEPARTAMENTO_REGION_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_REGION + "(" + ConstantsDatabase.TABLE_REGION_ID + ")" +
                ")";

        db.execSQL(queryCreateTableDepartamento);

        /**
         * Creación de la tabla Direccion.
         */
        String queryCreateTableDireccion = "CREATE TABLE " + ConstantsDatabase.TABLE_DIRECCION + "(" +
                ConstantsDatabase.TABLE_DIRECCION_ID                + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_DIRECCION_DESCRIPCION       + " TEXT, " +
                ConstantsDatabase.TABLE_DIRECCION_CIUDAD_FK         + " INTEGER, " +
                ConstantsDatabase.TABLE_DIRECCION_DOCUMENTO_FK      + " TEXT, " +
                ConstantsDatabase.TABLE_DIRECCION_TIPO_DOCUMENTO_FK + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_DIRECCION_CIUDAD_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_CIUDAD + "(" + ConstantsDatabase.TABLE_CIUDAD_ID + "), " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_DIRECCION_DOCUMENTO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_PERSONA + "(" + ConstantsDatabase.TABLE_PERSONA_DOCUMENTO + "), " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_DIRECCION_TIPO_DOCUMENTO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_PERSONA + "(" + ConstantsDatabase.TABLE_PERSONA_TIPO_DOCUMENTO_FK + ")" +
                ")";

        db.execSQL(queryCreateTableDireccion);

        /**
         * Creación de la tabla Opcion.
         */
        String queryCreateTableOpcion = "CREATE TABLE " + ConstantsDatabase.TABLE_OPCION + "(" +
                ConstantsDatabase.TABLE_OPCION_ID           + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_OPCION_VALOR        + " INTEGER, " +
                ConstantsDatabase.TABLE_OPCION_ESTADO       + " NUMERIC, " +
                ConstantsDatabase.TABLE_OPCION_ETIQUETA     + " TEXT, " +
                ConstantsDatabase.TABLE_OPCION_PREGUNTA_FK  + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_OPCION_PREGUNTA_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_PREGUNTA + "(" + ConstantsDatabase.TABLE_PREGUNTA_ID + ")" +
                ")";

        db.execSQL(queryCreateTableOpcion);

        /**
         * Creación de la tabla Pais.
         */
        String queryCreateTablePais = "CREATE TABLE " + ConstantsDatabase.TABLE_PAIS + "(" +
                ConstantsDatabase.TABLE_PAIS_ID             + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_PAIS_NOMBRE         + " TEXT, " +
                ConstantsDatabase.TABLE_PAIS_CONTINENTE_FK  + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_PAIS_CONTINENTE_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_CONTINENTE + "(" + ConstantsDatabase.TABLE_CONTINENTE_ID + ")" +
                ")";

        db.execSQL(queryCreateTablePais);

        /**
         * Creación de la tabla Persona.
         */
        String queryCreateTablePersona = "CREATE TABLE " + ConstantsDatabase.TABLE_PERSONA + "(" +
                ConstantsDatabase.TABLE_PERSONA_TIPO_DOCUMENTO_FK   + " INTEGER, " +
                ConstantsDatabase.TABLE_PERSONA_DOCUMENTO           + " TEXT, " +
                ConstantsDatabase.TABLE_PERSONA_NOMBRES             + " TEXT, " +
                ConstantsDatabase.TABLE_PERSONA_PRIMER_APELLIDO     + " TEXT, " +
                ConstantsDatabase.TABLE_PERSONA_SEGUNDO_APELLIDO    + " TEXT, " +
                ConstantsDatabase.TABLE_PERSONA_ESTADO_CIVIL        + " TEXT, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_PERSONA_TIPO_DOCUMENTO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_TIPO_DOCUMENTO + "(" + ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ID + "), " +
                " PRIMARY KEY " + "(" + ConstantsDatabase.TABLE_PERSONA_TIPO_DOCUMENTO_FK + "," +
                ConstantsDatabase.TABLE_PERSONA_DOCUMENTO + ")" +
                ")";

        db.execSQL(queryCreateTablePersona);

        /**
         * Creación de la tabla Persona_Encuesta.
         */
        String queryCreateTablePersonaEncuesta = "CREATE TABLE " + ConstantsDatabase.TABLE_PERSONA_ENCUESTA  + "(" +
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ID                 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_FECHA              + " TEXT, " +
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ESTADO             + " TEXT, " +
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_NUMERO_FK          + " INTEGER, " +
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_DOCUMENTO_FK       + " TEXT, " +
                ConstantsDatabase.TABLE_PERSONA_ENCUESTA_TIPO_DOCUMENTO_FK  + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_PERSONA_ENCUESTA_NUMERO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_ENCUESTA + "(" + ConstantsDatabase.TABLE_ENCUESTA_NUMERO + "), " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_PERSONA_ENCUESTA_DOCUMENTO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_PERSONA + "(" + ConstantsDatabase.TABLE_PERSONA_DOCUMENTO + "), " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_PERSONA_ENCUESTA_TIPO_DOCUMENTO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_PERSONA + "(" + ConstantsDatabase.TABLE_PERSONA_TIPO_DOCUMENTO_FK + ")" +
                ")";

        db.execSQL(queryCreateTablePersonaEncuesta);

        /**
         * Creación de la tabla Pregunta.
         */
        String queryCreateTablePregunta = "CREATE TABLE " + ConstantsDatabase.TABLE_PREGUNTA  + "(" +
                ConstantsDatabase.TABLE_PREGUNTA_ID                 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_PREGUNTA_TEXTO              + " TEXT, " +
                ConstantsDatabase.TABLE_PREGUNTA_NUMERO_FK          + " INTEGER, " +
                ConstantsDatabase.TABLE_PREGUNTA_TIPO_RESPUESTA_FK  + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_PREGUNTA_NUMERO_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_ENCUESTA + "(" + ConstantsDatabase.TABLE_ENCUESTA_NUMERO + "), " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_PREGUNTA_TIPO_RESPUESTA_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_TIPO_RESPUESTA + "(" + ConstantsDatabase.TABLE_TIPO_RESPUESTA_ID + ")" +
                ")";

        db.execSQL(queryCreateTablePregunta);

        /**
         * Creación de la tabla Region.
         */
        String queryCreateTableRegion = "CREATE TABLE " + ConstantsDatabase.TABLE_REGION  + "(" +
                ConstantsDatabase.TABLE_REGION_ID       + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_REGION_NOMBRE   + " TEXT, " +
                ConstantsDatabase.TABLE_REGION_PAIS_FK  + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_REGION_PAIS_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_REGION + "(" + ConstantsDatabase.TABLE_REGION_ID + ")" +
                ")";

        db.execSQL(queryCreateTableRegion);

        /**
         * Creación de la tabla Respuesta.
         */
        String queryCreateTableRespuesta = "CREATE TABLE " + ConstantsDatabase.TABLE_RESPUESTA  + "(" +
                ConstantsDatabase.TABLE_RESPUESTA_ID                    + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_RESPUESTA_VALOR                 + " TEXT, " +
                ConstantsDatabase.TABLE_RESPUESTA_PREGUNTA_FK           + " INTEGER, " +
                ConstantsDatabase.TABLE_RESPUESTA_PERSONA_ENCUESTA_FK   + " INTEGER, " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_RESPUESTA_PREGUNTA_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_PREGUNTA + "(" + ConstantsDatabase.TABLE_PREGUNTA_ID + "), " +
                " FOREIGN KEY (" + ConstantsDatabase.TABLE_RESPUESTA_PERSONA_ENCUESTA_FK + ") " +
                " REFERENCES "+ ConstantsDatabase.TABLE_PERSONA_ENCUESTA + "(" + ConstantsDatabase.TABLE_PERSONA_ENCUESTA_ID + ")" +
                ")";

        db.execSQL(queryCreateTableRespuesta);

        /**
         * Creación de la tabla Tipo_Contacto.
         */
        String queryCreateTableTipoContacto = "CREATE TABLE " + ConstantsDatabase.TABLE_TIPO_CONTACTO  + "(" +
                ConstantsDatabase.TABLE_TIPO_CONTACTO_ID            + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_TIPO_CONTACTO_NOMBRE        + " TEXT, " +
                ConstantsDatabase.TABLE_TIPO_CONTACTO_DESCRIPCION   + " TEXT" +
                ")";

        db.execSQL(queryCreateTableTipoContacto);

        /**
         * Creación de la tabla Tipo_Documento.
         */
        String queryCreateTableTipoDocumento = "CREATE TABLE " + ConstantsDatabase.TABLE_TIPO_DOCUMENTO  + "(" +
                ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ID            + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_TIPO_DOCUMENTO_NOMBRE        + " TEXT, " +
                ConstantsDatabase.TABLE_TIPO_DOCUMENTO_ABREVIATURA   + " TEXT, " +
                ConstantsDatabase.TABLE_TIPO_DOCUMENTO_DESCRIPCION   + " TEXT" +
                ")";

        db.execSQL(queryCreateTableTipoDocumento);

        /**
         * Creación de la tabla Tipo_Respuesta.
         */
        String queryCreateTableTipoRespuesta = "CREATE TABLE " + ConstantsDatabase.TABLE_TIPO_RESPUESTA  + "(" +
                ConstantsDatabase.TABLE_TIPO_RESPUESTA_ID            + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantsDatabase.TABLE_TIPO_RESPUESTA_NOMBRE        + " TEXT, " +
                ConstantsDatabase.TABLE_TIPO_RESPUESTA_DESCRIPCION   + " TEXT" +
                ")";

        db.execSQL(queryCreateTableTipoRespuesta);
    }

    /**
     * Método que permite generar una actualización a la base de datos.
     * @param db, base de datos a la cual se le generarán los cambios.
     * @param i
     * @param i1
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_ENCUESTA);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_CIUDAD);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_CONTINENTE);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_DEPARTAMENTO);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_DIRECCION);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_OPCION);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_PAIS);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_PERSONA);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_PERSONA_ENCUESTA);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_PREGUNTA);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_REGION);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_RESPUESTA);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_TIPO_CONTACTO);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_TIPO_DOCUMENTO);
        db.execSQL("DROP IF EXIST " + ConstantsDatabase.TABLE_TIPO_RESPUESTA);
        onCreate(db);
    }

    /**
     * Método que permite listar los registros de una tabla.
     * @return c, lista de los registros.
     */
    public Cursor getAll(String table) {

        String query = "SELECT * FROM " + table;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(query, null);
        return c;
    }

    /**
     * Método que permite listar todos los registros de una tabla.
     * @param query, sql realizado para consultar la tabla.
     * @return c, lista de los registros.
     */
    public Cursor getAllQuery(String query){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(query, null);
        return c;
    }

    /**
     * Método que permite listar todos los registros por medio de una llave compuesta.
     * @param table, tabla en la que se encuentran los registros.
     * @param field1, primer campo que corresponde a la llave compuesta.
     * @param value1, valor del primer campo que compone a la llave compuesta.
     * @param field2, segundo campo que corresponde a la llave compuesta.
     * @param value2, valor del segundo campo que compone a la llave compuesta.
     * @return c, lista de los registros.
     */
    public Cursor getAllCompositeKey(String table, String field1, int value1, String field2, String value2) {

        String query = "SELECT * FROM " + table + " WHERE " + field1 + "=" + value1 + " and " + field2 + "=" + value2;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(query, null);
        return c;
    }

    /**
     * Método que permite generar el casteo de una cadena a una fecha.
     * @param cad, cadena a convertir en fecha.
     * @return date, fecha establecidad a partir de la cadena.
     */
    public Date castDate(String cad) {
        Date date = null;
        try {
            DateFormat readFormat = new SimpleDateFormat( "EEE MMM dd HH:mm:ss Z yyyy");
            readFormat.setLenient(true);
            DateFormat writeFormat = new SimpleDateFormat( "yyyy-MM-dd");
            date = readFormat.parse(cad);

            String formattedDate = "";
            if( date != null ) {
                formattedDate = writeFormat.format(date);
            }

            date = writeFormat.parse(formattedDate);

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    /**
     * Método que permite insertar registros en una tabla.
     * @param contentValues, contenedor de los datos pertenecientes a la tabla.
     */
    public void insertRecord(String table, ContentValues contentValues) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
                 db.insert(table, null, contentValues);
        }
        catch (SQLiteException exception) {
            DatabaseMessage message = new DatabaseMessage(exception.getMessage(), table, DatabaseMessage.MESSAGE_ERROR, context);
            message.mostrarMensaje(DatabaseMessage.MESSAGE_ERROR);
        }
        finally {
            db.close();
        }
    }

    /**
     * Método que permite buscar un registro en la base de datos.
     * @param table, tabla en la cual se va a buscar el registro.
     * @param field, llave que se va a usar para buscar el registro.
     * @param fields, campos de la tabla que va a devolver la consulta.
     * @param parameters, parametros que se necesitan para hacer la busqueda del registro.
     * @return c, lista de los registros encontrados.
     */
    public Cursor searchRecord(String table, String field, String[] fields, String[] parameters) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.query(table, fields, field+"=?", parameters, null, null, null);
        return c;
    }

    /**
     * Método que permite ralizar una consulta a una tabla.
     * @param query, consulta que se desea realizar.
     * @return c, lista de registros de la tabla de acuerdo a la consulta.
     */
    public Cursor search(String query){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(query, null);
        return c;
    }

    /**
     * Método que permite buscar un registro por medio de una llave compuesta.
     * @param table, tabla en la cual se encuentra el registro a buscar.
     * @param param1, valor de la llave primaria compuesta por el primer campo.
     * @param param2, valor de la llave primaria compuesta por el segundo campo.
     * @param field1, primer campo que compone la llave primaria.
     * @param field2, segundo campo que compone la llave primaria.
     * @return c, registro que se buscaba.
     */
    public Cursor searchRecordCompositeKey(String table, String param1, String param2, String field1, String field2){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(" SELECT * FROM " + table + " WHERE " +
                field1 + "=" + "'" + param1 + "'" + " and " + field2 +"=" + "'" + param2 + "'", null);
        return c;
    }

    /**
     * Método que permite modificar o actualizar un registro.
     * @param table, tabla en la cual se encuentra el registro a editar.
     * @param contentValues, contenedor de valores editados.
     * @param field, llave que se va a usar para hubicar el registro.
     * @param value, valor de la llave del registro a modificar.
     */
    public void editRecord(String table, ContentValues contentValues, String field, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.update(table, contentValues, field+"="+value, null);
        db.close();
    }

    /**
     * Método que permite modificar o actualizar un registro.
     * @param table, tabla en la cual se encuentra el registro a editar.
     * @param contentValues, contenedor de valores editados.
     * @param field1, primer campo que compone la llave compuesta que se va a usar para hubicar el registro.
     * @param value1, primer valor de la llave del registro a modificar.
     * @param field2, segundo campo que compone la llave compuesta que se va a usar para hubicar el registro.
     * @param value2, segundo valor de la llave del registro a modificar.
     */
    public void editRecordCompositeKey(String table, ContentValues contentValues,
                                       String field1, String value1, String field2, String value2) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.update(table, contentValues, field1+"="+value1+" and "+field2+"="+value2, null);
        db.close();
    }

    /**
     * Método que permite eliminar un registro.
     * @param table, tabla en la cual se encuentra el registro a eliminar.
     * @param field, llave que se va a usar para hubicar el registro.
     * @param value, valor de la llave del registro a eliminar.
     */
    public void deleteRecord(String table, String field, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(table, field+"="+value, null);
        db.close();
    }

    /**
     * Método que permite eliminar un registro.
     * @param table, tabla en la cual se encuentra el registro a eliminar.
     * @param field1, primer campo que compone la llave compuesta que se va a usar para hubicar el registro.
     * @param value1, primer valor de la llave del registro a eliminar.
     * @param field2, segundo campo que compone la llave compuesta que se va a usar para hubicar el registro.
     * @param value2, segundo valor de la llave del registro a eliminar.
     */
    public void deleteRecordCompositeKey(String table, String field1, String value1, String field2, String value2) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(table, field1+"="+value1+" and "+field2+"="+value2, null);
        db.close();
    }
}