package com.coursera.expertsurvey.pojo;

import java.util.Date;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class PersonaEncuesta {

    /**
     * Atributos de la clase.
     */
    private int idEncuestaPersona;
    private String estado;
    private Date fecha;
    private int numeroEncuestaFK;
    private int idTipoDocumentoFK;
    private String documentoFK;

    /**
     * Método constructor por default de la clase.
     */
    public PersonaEncuesta() {
    }

    /**
     * Método constructor de la clase.
     * @param estado,
     * @param fecha, fecha en que diligencio la encuesta.
     * @param numeroEncuestaFK, número de encuesta que se diligencio.
     * @param idTipoDocumentoFK, identificador del tipo de documento perteneciente a la persona.
     * @param documentoFK, documento perteneciente a la persona.
     */
    public PersonaEncuesta(String estado, Date fecha, int numeroEncuestaFK, int idTipoDocumentoFK, String documentoFK) {
        this.estado = estado;
        this.fecha = fecha;
        this.numeroEncuestaFK = numeroEncuestaFK;
        this.idTipoDocumentoFK = idTipoDocumentoFK;
        this.documentoFK = documentoFK;
    }

    /**
     * Método accesor del atributo idEncuestaPersona.
     * @return idEncuestaPersona, valor del atributo establecido.
     */
    public int getIdEncuestaPersona() {
        return idEncuestaPersona;
    }

    /**
     * Método modificador correspondiente al valor del atributo idEncuestaPersona.
     * @param idEncuestaPersona, valor que se va a establecer en el atributo.
     */
    public void setIdEncuestaPersona(int idEncuestaPersona) {
        this.idEncuestaPersona = idEncuestaPersona;
    }

    /**
     * Método accesor del atributo estado.
     * @return estado, valor del atributo establecido.
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Método modificador correspondiente al valor del atributo estado.
     * @param estado, valor que se va a establecer en el atributo.
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Método accesor del atributo fecha.
     * @return fecha, valor del atributo establecido.
     */
    public Date getFecha() {
        return fecha;
    }

    /**
     * Método modificador correspondiente al valor del atributo fecha.
     * @param fecha, valor que se va a establecer en el atributo.
     */
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    /**
     * Método accesor del atributo numeroEncuestaFK.
     * @return numeroEncuestaFK, valor del atributo establecido.
     */
    public int getNumeroEncuestaFK() {
        return numeroEncuestaFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo numeroEncuestaFK.
     * @param numeroEncuestaFK, valor que se va a establecer en el atributo.
     */
    public void setNumeroEncuestaFK(int numeroEncuestaFK) {
        this.numeroEncuestaFK = numeroEncuestaFK;
    }

    /**
     * Método accesor del atributo idTipoDocumentoFK.
     * @return idTipoDocumentoFK, valor del atributo establecido.
     */
    public int getIdTipoDocumentoFK() {
        return idTipoDocumentoFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idTipoDocumentoFK.
     * @param idTipoDocumentoFK, valor que se va a establecer en el atributo.
     */
    public void setIdTipoDocumentoFK(int idTipoDocumentoFK) {
        this.idTipoDocumentoFK = idTipoDocumentoFK;
    }

    /**
     * Método accesor del atributo documentoFK.
     * @return documentoFK, valor del atributo establecido.
     */
    public String getDocumentoFK() {
        return documentoFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo documentoFK.
     * @param documentoFK, valor que se va a establecer en el atributo.
     */
    public void setDocumentoFK(String documentoFK) {
        this.documentoFK = documentoFK;
    }
}
