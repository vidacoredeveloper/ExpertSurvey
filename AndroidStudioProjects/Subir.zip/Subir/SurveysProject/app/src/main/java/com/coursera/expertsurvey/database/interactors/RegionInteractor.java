package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Region;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class RegionInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public RegionInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public RegionInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar una region.
     * @param db, base de datos donde se buscara la region.
     * @param cod, identificador de la region a buscar.
     * @return region, registro de la region buscada.
     */
    public Region searchRegion(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_REGION_ID,
                ConstantsDatabase.TABLE_REGION_NOMBRE, ConstantsDatabase.TABLE_REGION_PAIS_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_REGION,
                ConstantsDatabase.TABLE_REGION_ID, fields, parameters);

        Region region = new Region();

        if (cursor.moveToFirst()) {
            region.setIdRegion(cursor.getInt(0));
            region.setNombre(cursor.getString(1));
            region.setIdPaisFK(cursor.getInt(2));
        }

        return region;
    }

    /**
     * Método que permite insertar una region.
     * @param db, base de datos en la cual se insertara la region.
     * @param region, region a insertar en la base de datos.
     */
    public void insertRegion(DataBase db, Region region) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_REGION_ID, region.getIdRegion());
        contentValues.put(ConstantsDatabase.TABLE_REGION_NOMBRE, region.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_REGION_PAIS_FK, region.getIdPaisFK());

        db.insertRecord(ConstantsDatabase.TABLE_REGION, contentValues);
    }

    /**
     * Método que permite modificar el registro de una region.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param region, region a la cual se le modificaran los datos.
     */
    public void modifyRegion(DataBase db, Region region) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_REGION_ID, region.getIdRegion());
        contentValues.put(ConstantsDatabase.TABLE_REGION_NOMBRE, region.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_REGION_PAIS_FK, region.getIdPaisFK());

        db.editRecord(ConstantsDatabase.TABLE_REGION, contentValues, ConstantsDatabase.TABLE_REGION_ID,
                region.getIdRegion()+"");
    }

    /**
     * Método que permite eliminar una region.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteRegion(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_REGION, ConstantsDatabase.TABLE_REGION_ID, id+"");
    }

    /**
     * Método que permite obtener todas las regiones.
     * @param db, base de datos donde se encuentran los registros.
     * @return regiones, lista de las regiones registradas.
     */
    public ArrayList<Region> getRegion(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_REGION);
        ArrayList<Region> regiones = new ArrayList<>();

        while (registros.moveToNext()) {
            Region region = new Region();
            region.setIdRegion(registros.getInt(0));
            region.setNombre(registros.getString(1));
            region.setIdPaisFK(registros.getInt(2));
            regiones.add(region);
        }

        return regiones;
    }
}
