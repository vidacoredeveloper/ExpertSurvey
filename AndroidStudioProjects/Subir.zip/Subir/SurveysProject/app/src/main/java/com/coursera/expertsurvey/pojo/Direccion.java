package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Direccion {

    /**
     * Atributos de la clase.
     */
    private int idDireccion;
    private String descripcion;
    private int idCiudadFK;
    private int idTipoDocumentoFK;
    private String documentoFK;

    /**
     * Método constructor por default de la clase.
     */
    public Direccion() {
    }

    /**
     * Método constructor de la clase.
     * @param descripcion, valor que se va a establecer en el atributo.
     * @param idCiudadFK, identificador de la ciudad a la esta vínculada la ciudad.
     * @param idTipoDocumentoFK, identificador del tipo de documento de la persona.
     * @param documentoFK, documento de identificación de la persona.
     */
    public Direccion(String descripcion, int idCiudadFK, int idTipoDocumentoFK, String documentoFK) {
        this.descripcion = descripcion;
        this.idCiudadFK = idCiudadFK;
        this.idTipoDocumentoFK = idTipoDocumentoFK;
        this.documentoFK = documentoFK;
    }

    /**
     * Método accesor del atributo idDireccion.
     * @return idDireccion, valor del atributo establecido.
     */
    public int getIdDireccion() {
        return idDireccion;
    }

    /**
     * Método modificador correspondiente al valor del atributo idDireccion.
     * @param idDireccion, valor que se va a establecer en el atributo.
     */
    public void setIdDireccion(int idDireccion) {
        this.idDireccion = idDireccion;
    }

    /**
     * Método accesor del atributo descripcion.
     * @return descripcion, valor del atributo establecido.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Método modificador correspondiente al valor del atributo descripcion.
     * @param descripcion, valor que se va a establecer en el atributo.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Método accesor del atributo idCiudadFK.
     * @return idCiudadFK, valor del atributo establecido.
     */
    public int getIdCiudadFK() {
        return idCiudadFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idCiudadFK.
     * @param idCiudadFK, valor que se va a establecer en el atributo.
     */
    public void setIdCiudadFK(int idCiudadFK) {
        this.idCiudadFK = idCiudadFK;
    }

    /**
     * Método accesor del atributo idTipoDocumentoFK.
     * @return idTipoDocumentoFK, valor del atributo establecido.
     */
    public int getIdTipoDocumentoFK() {
        return idTipoDocumentoFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idTipoDocumentoFK.
     * @param idTipoDocumentoFK, valor que se va a establecer en el atributo.
     */
    public void setIdTipoDocumentoFK(int idTipoDocumentoFK) {
        this.idTipoDocumentoFK = idTipoDocumentoFK;
    }

    /**
     * Método accesor del atributo documentoFK.
     * @return documentoFK, valor del atributo establecido.
     */
    public String getDocumentoFK() {
        return documentoFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo documentoFK.
     * @param documentoFK, valor que se va a establecer en el atributo.
     */
    public void setDocumentoFK(String documentoFK) {
        this.documentoFK = documentoFK;
    }
}
