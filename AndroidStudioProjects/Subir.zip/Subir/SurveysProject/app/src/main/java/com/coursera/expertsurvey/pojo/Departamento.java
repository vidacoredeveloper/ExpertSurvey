package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Departamento {

    /**
     * Atributos de la clase.
     */
    private int idDepartamento;
    private String nombre;
    private int idRegionFK;

    /**
     * Método constructor por default de la clase.
     */
    public Departamento() {
    }

    /**
     * Método constructor de la clase.
     * @param nombre, nombre de la ciudad.
     * @param idRegionFK, región a la cual pertence el departamento.
     */
    public Departamento(String nombre, int idRegionFK) {
        this.nombre = nombre;
        this.idRegionFK = idRegionFK;
    }

    /**
     * Método accesor del atributo idDepartamento.
     * @return idDepartamento, valor del atributo establecido.
     */
    public int getIdDepartamento() {
        return idDepartamento;
    }

    /**
     * Método modificador correspondiente al valor del atributo idDepartamento.
     * @param idDepartamento, valor que se va a establecer en el atributo.
     */
    public void setIdDepartamento(int idDepartamento) {
        this.idDepartamento = idDepartamento;
    }

    /**
     * Método accesor del atributo nombre.
     * @return nombre, valor del atributo establecido.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombre.
     * @param nombre, valor que se va a establecer en el atributo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método accesor del atributo idRegionFK.
     * @return idRegionFK, valor del atributo establecido.
     */
    public int getIdRegionFK() {
        return idRegionFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idRegionFK.
     * @param idRegionFK, valor que se va a establecer en el atributo.
     */
    public void setIdRegionFK(int idRegionFK) {
        this.idRegionFK = idRegionFK;
    }
}
