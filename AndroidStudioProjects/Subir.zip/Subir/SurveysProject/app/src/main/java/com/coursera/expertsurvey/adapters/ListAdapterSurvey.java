package com.coursera.expertsurvey.adapters;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.coursera.expertsurvey.MainActivity;
import com.coursera.expertsurvey.ProfileActivity;
import com.coursera.expertsurvey.R;
import com.coursera.expertsurvey.pojo.Encuesta;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 12/12/16.
 */

public class ListAdapterSurvey extends RecyclerView.Adapter<ListAdapterSurvey.ListAdapterSurveyViewHolder> {

    /**
     * Atributos de la clase.
     */
    private ArrayList<Encuesta> encuestas;
    private Activity activity;

    /**
     * Método constructor de la clase.
     * @param encuestas, lista de encuestas.
     * @param activity, actividad en la que se encuentra el recycler.
     */
    public ListAdapterSurvey(ArrayList<Encuesta> encuestas, Activity activity) {
        this.encuestas = encuestas;
        this.activity = activity;
    }

    /**
     * Método que permite inflar el layout pasandolo al view holder para realizar el uso de los views.
     * @param parent, grupo de views a los cuales se realizará la inflación.
     * @param viewType, tipo de la view a la que se le realizará la inflación.
     * @return
     */
    @Override
    public ListAdapterSurveyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.survey_card_view, parent, false);
        return new ListAdapterSurveyViewHolder(view);
    }

    /**
     * Método que realiza la asociación de cada elemento de a los view de la vista.
     * @param listAdapterSurveyViewHolder, view al cual se le realizará la asociación de los elementos.
     * @param position, posicion del elemnto que se va asociar en la lista.
     */
    @Override
    public void onBindViewHolder(ListAdapterSurveyViewHolder listAdapterSurveyViewHolder, int position) {
        Encuesta encuesta = encuestas.get(position);
        MainActivity.encuesta = encuesta;
        listAdapterSurveyViewHolder.tvTittleSurveyCardSCV.setText(encuesta.getNombre());
        addListenerLayout(listAdapterSurveyViewHolder.llSurveyCardSCV, encuesta.getNumero());
    }

    /**
     * Método que permite conocer la cantidad de elementos de la lista.
     * @return size, cantidad de elementos de la lista.
     */
    @Override
    public int getItemCount() {
        return encuestas.size();
    }

    /**
     * Clase statica que permite la interacción entre los objetos y las views.
     */
    public static class ListAdapterSurveyViewHolder extends RecyclerView.ViewHolder {

        /**
         * Views de la vista.
         */
        private LinearLayout llSurveyCardSCV;
        private ImageView ivSurveyCardSCV;
        private TextView tvTittleSurveyCardSCV;

        /**
         * Método constructor de la clase.
         * @param itemView, vista a la cual pertenecen los elementos.
         */
        public ListAdapterSurveyViewHolder(View itemView) {
            super(itemView);

            llSurveyCardSCV         = (LinearLayout) itemView.findViewById(R.id.llSurveyCardSCV);
            ivSurveyCardSCV         = (ImageView) itemView.findViewById(R.id.ivSurveyCardSCV);
            tvTittleSurveyCardSCV   = (TextView) itemView.findViewById(R.id.tvTittleSurveyCardSCV);
        }
    }

    /**
     * Método que permite generar el escuchador a un linear layout
     * @param linearLayout, linear layout al cual se le genera el escuchador.
     */
    private void addListenerLayout(LinearLayout linearLayout, final int id) {
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, ProfileActivity.class);
                MainActivity.id = id;
                activity.startActivity(intent);
            }
        });
    }
}
