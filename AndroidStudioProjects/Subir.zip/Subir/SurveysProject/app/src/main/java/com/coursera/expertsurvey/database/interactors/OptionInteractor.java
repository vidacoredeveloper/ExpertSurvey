package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Opcion;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class OptionInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public OptionInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public OptionInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar una opcion.
     * @param db, base de datos donde se buscara la opcion.
     * @param cod, identificador de la opcion a buscar.
     * @return opcion, registro de la opcion buscada.
     */
    public Opcion searchOption(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_OPCION_ID,
                ConstantsDatabase.TABLE_OPCION_VALOR, ConstantsDatabase.TABLE_OPCION_ESTADO,
                ConstantsDatabase.TABLE_OPCION_ETIQUETA, ConstantsDatabase.TABLE_OPCION_PREGUNTA_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_OPCION, ConstantsDatabase.TABLE_OPCION_ID, fields, parameters);

        Opcion opcion = new Opcion();

        if (cursor.moveToFirst()) {
            opcion.setIdOpcion(cursor.getInt(0));
            opcion.setEtiqueta(cursor.getString(1));
            opcion.setEstado(Boolean.valueOf(cursor.getString(2)));
            opcion.setValor(cursor.getInt(3));
            opcion.setIdPreguntaFK(cursor.getInt(4));
        }

        return opcion;
    }

    /**
     * Método que permite insertar una opcion.
     * @param db, base de datos en la cual se insertara la opcion.
     * @param opcion, opcion a insertar en la base de datos.
     */
    public void insertOption(DataBase db, Opcion opcion) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_OPCION_VALOR, opcion.getValor());
        contentValues.put(ConstantsDatabase.TABLE_OPCION_ESTADO, opcion.isEstado());
        contentValues.put(ConstantsDatabase.TABLE_OPCION_ETIQUETA, opcion.getEtiqueta());
        contentValues.put(ConstantsDatabase.TABLE_OPCION_PREGUNTA_FK, opcion.getIdPreguntaFK());

        db.insertRecord(ConstantsDatabase.TABLE_OPCION, contentValues);
    }

    /**
     * Método que permite modificar el registro de una opcion.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param opcion, opcion a la cual se le modificaran los datos.
     */
    public void modifyOption(DataBase db, Opcion opcion) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_OPCION_VALOR, opcion.getValor());
        contentValues.put(ConstantsDatabase.TABLE_OPCION_ESTADO, opcion.isEstado());
        contentValues.put(ConstantsDatabase.TABLE_OPCION_ETIQUETA, opcion.getEtiqueta());
        contentValues.put(ConstantsDatabase.TABLE_OPCION_PREGUNTA_FK, opcion.getIdPreguntaFK());

        db.editRecord(ConstantsDatabase.TABLE_OPCION, contentValues, ConstantsDatabase.TABLE_OPCION_ID,
                opcion.getIdOpcion()+"");
    }

    /**
     * Método que permite eliminar una opcion.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteOption(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_OPCION, ConstantsDatabase.TABLE_OPCION_ID, id+"");
    }

    /**
     * Método que permite obtener todas las opciones.
     * @param db, base de datos donde se encuentran los registros.
     * @param idQuestion, identificador de la pregunta a la cual pertenecen las opciones a listar.
     * @return opciones, lista de las opciones registradas.
     */
    public ArrayList<Opcion> getOptionsQuestion(DataBase db, int idQuestion) {
        String query = "SELECT * FROM " + ConstantsDatabase.TABLE_OPCION + " WHERE " +
                ConstantsDatabase.TABLE_OPCION_PREGUNTA_FK + " = " + idQuestion;
        Cursor registros = db.getAllQuery(query);
        ArrayList<Opcion> opciones = new ArrayList<>();

        while (registros.moveToNext()) {
            Opcion opcion = new Opcion();
            opcion.setIdOpcion(registros.getInt(0));
            opcion.setValor(registros.getInt(1));
            opcion.setEstado(Boolean.valueOf(registros.getString(2)));
            opcion.setEtiqueta(registros.getString(3));
            opcion.setIdPreguntaFK(registros.getInt(4));
            opciones.add(opcion);
        }

        return opciones;
    }
}
