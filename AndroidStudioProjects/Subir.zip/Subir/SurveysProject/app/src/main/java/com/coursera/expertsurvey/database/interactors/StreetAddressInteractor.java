package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Direccion;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class StreetAddressInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public StreetAddressInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public StreetAddressInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar una direccion.
     * @param db, base de datos donde se buscara la direccion.
     * @param cod, identificador de la direccion a buscar.
     * @return direccion, registro de la direccion buscada.
     */
    public Direccion searchAddress(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_DIRECCION_ID,
                ConstantsDatabase.TABLE_DIRECCION_DESCRIPCION, ConstantsDatabase.TABLE_DIRECCION_CIUDAD_FK,
                ConstantsDatabase.TABLE_DIRECCION_DOCUMENTO_FK, ConstantsDatabase.TABLE_DIRECCION_TIPO_DOCUMENTO_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_DIRECCION,
                ConstantsDatabase.TABLE_DIRECCION_ID, fields, parameters);

        Direccion direccion = new Direccion();

        if (cursor.moveToFirst()) {
            direccion.setIdDireccion(cursor.getInt(0));
            direccion.setDescripcion(cursor.getString(1));
            direccion.setIdCiudadFK(cursor.getInt(2));
            direccion.setDocumentoFK(cursor.getString(3));
            direccion.setIdTipoDocumentoFK(cursor.getInt(4));
        }

        return direccion;
    }

    /**
     * Método que permite insertar una direccion.
     * @param db, base de datos en la cual se insertara la direccion.
     * @param direccion, direccion a insertar en la base de datos.
     */
    public void insertAddress(DataBase db, Direccion direccion) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_ID, direccion.getIdDireccion());
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_DESCRIPCION, direccion.getDescripcion());
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_CIUDAD_FK, direccion.getIdCiudadFK());
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_DOCUMENTO_FK, direccion.getDocumentoFK());
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_TIPO_DOCUMENTO_FK, direccion.getIdTipoDocumentoFK());

        db.insertRecord(ConstantsDatabase.TABLE_DIRECCION, contentValues);
    }

    /**
     * Método que permite modificar el registro de una direccion.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param direccion, direccion a la cual se le modificaran los datos.
     */
    public void modifyAddress(DataBase db, Direccion direccion) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_ID, direccion.getIdDireccion());
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_DESCRIPCION, direccion.getDescripcion());
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_CIUDAD_FK, direccion.getIdCiudadFK());
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_DOCUMENTO_FK, direccion.getDocumentoFK());
        contentValues.put(ConstantsDatabase.TABLE_DIRECCION_TIPO_DOCUMENTO_FK, direccion.getIdTipoDocumentoFK());

        db.editRecord(ConstantsDatabase.TABLE_DIRECCION, contentValues, ConstantsDatabase.TABLE_DIRECCION_ID,
                direccion.getIdDireccion()+"");
    }

    /**
     * Método que permite eliminar una direccion.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteAddress(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_DIRECCION, ConstantsDatabase.TABLE_DIRECCION_ID, id+"");
    }

    /**
     * Método que permite obtener todas las direcciones.
     * @param db, base de datos donde se encuentran los registros.
     * @return direcciones, lista de las direcciones registradas.
     */
    public ArrayList<Direccion> getAddresses(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_DIRECCION);
        ArrayList<Direccion> direcciones = new ArrayList<>();

        while (registros.moveToNext()) {
            Direccion direccion = new Direccion();
            direccion.setIdDireccion(registros.getInt(0));
            direccion.setDescripcion(registros.getString(1));
            direccion.setIdCiudadFK(registros.getInt(2));
            direccion.setDocumentoFK(registros.getString(3));
            direccion.setIdTipoDocumentoFK(registros.getInt(4));
            direcciones.add(direccion);
        }

        return direcciones;
    }
}
