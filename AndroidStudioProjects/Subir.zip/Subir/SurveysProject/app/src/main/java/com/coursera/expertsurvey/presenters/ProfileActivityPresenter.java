package com.coursera.expertsurvey.presenters;

import android.content.Context;
import android.widget.ArrayAdapter;

import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.database.interactors.ContactInteractor;
import com.coursera.expertsurvey.database.interactors.PersonInteractor;
import com.coursera.expertsurvey.database.interactors.TypeDocumentInteractor;
import com.coursera.expertsurvey.pojo.Contacto;
import com.coursera.expertsurvey.pojo.Persona;
import com.coursera.expertsurvey.pojo.TipoDocumento;
import com.coursera.expertsurvey.presenters.interfaces.IProfileActivityPresenter;
import com.coursera.expertsurvey.viewmodel.IProfileActivityView;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 19/12/16.
 */

public class ProfileActivityPresenter implements IProfileActivityPresenter{

    /**
     * Atributos de la clase.
     */
    private Context context;
    private ArrayList<Contacto> contacts;
    private PersonInteractor personInteractor;
    private ContactInteractor contactInteractor;
    private IProfileActivityView iProfileActivityView;
    private TypeDocumentInteractor typeDocumentInteractor;

    /**
     * Método constructor de la clase.
     * @param iProfileActivityView, instacia de la interface de la vista principal.
     * @param context, contexto de la vista principal.
     */
    public ProfileActivityPresenter(IProfileActivityView iProfileActivityView, Context context) {
        this.iProfileActivityView = iProfileActivityView;
        this.context = context;
    }

    /**
     * Método que permite buscar una persona.
     * @param type, tipo de documento por el cual se realizará la búsqueda de la persona.
     * @param document, documento por el cual se realizará la búsqueda de la persona.
     */
    @Override
    public Persona searchPerson(int type, String document) {
        personInteractor = new PersonInteractor(context);
        Persona persona = personInteractor.searchPerson(new DataBase(context), type, document);

        if(persona != null){
            return persona;
        }
        else {
            return null;
        }
    }

    @Override
    public ArrayAdapter getTypeDocument() {
        typeDocumentInteractor = new TypeDocumentInteractor(context);
        ArrayList<TipoDocumento> tiposDocumento = typeDocumentInteractor.getTypesDocument(new DataBase(context));
        ArrayAdapter array = new ArrayAdapter(context, android.R.layout.simple_spinner_item, tiposDocumento);
        array.insert(new String("Seleccionar"), 0);
        return array;
    }

    /**
     * Método que permite extraer los contactos de la base de datos según la persona.
     * @param type, tipo de documento por el cual se realizará la búsqueda de los contactos de la persona.
     * @param document, documento por el cual se realizará la búsqueda de los contactos de la persona.
     */
    @Override
    public void getContactsPerson(int type, String document) {
        contactInteractor = new ContactInteractor(context);
        contacts = contactInteractor.getContactsPerson(type, document);
        showContactsReclyclerView();
    }

    /**
     * Método que permite mostrar los contactos en la vista.
     */
    @Override
    public void showContactsReclyclerView() {
        iProfileActivityView.initializeAdapterRecyclerView(iProfileActivityView.initializeListAdapterSurvey(contacts));
        iProfileActivityView.setLayoutRecyclerView();
    }
}
