package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Encuesta;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 13/12/16.
 */

public class SurveyInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public SurveyInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public SurveyInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar una encuesta.
     * @param db, base de datos donde se buscara la encuesta.
     * @param cod, identificador de la encuesta a buscar.
     * @return encuesta, registro de la encuesta buscada.
     */
    public Encuesta searchSurvey(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_ENCUESTA_NUMERO, ConstantsDatabase.TABLE_ENCUESTA_NOMBRE,
                ConstantsDatabase.TABLE_ENCUESTA_FECHA, ConstantsDatabase.TABLE_ENCUESTA_CANTIDAD,
                ConstantsDatabase.TABLE_ENCUESTA_VIGENCIA};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_ENCUESTA, ConstantsDatabase.TABLE_ENCUESTA_NUMERO, fields, parameters);

        Encuesta encuesta = new Encuesta();

        if (cursor.moveToFirst()) {
            encuesta.setNumero(cursor.getInt(0));
            encuesta.setNombre(cursor.getString(1));
            encuesta.setFechaCreacion(db.castDate(cursor.getString(2)));
            encuesta.setCantidadPreguntas(cursor.getInt(3));
            encuesta.setVigente(Boolean.valueOf(cursor.getString(4)));
        }

        return encuesta;
    }

    /**
     * Método que permite consultar todas las encuestas de la base de datos.
     * @return encuestas, lista de las encuestas.
     */
    public ArrayList<Encuesta> getSurveys(DataBase dataBase) {

        Cursor registros = dataBase.getAll(ConstantsDatabase.TABLE_ENCUESTA);
        ArrayList<Encuesta> encuestas = new ArrayList<>();

        while (registros.moveToNext()) {
            Encuesta encuestaActual = new Encuesta();
            encuestaActual.setNumero(registros.getInt(0));
            encuestaActual.setNombre(registros.getString(1));
            encuestaActual.setFechaCreacion(dataBase.castDate(registros.getString(2)));
            encuestaActual.setCantidadPreguntas(registros.getInt(3));
            encuestaActual.setVigente(Boolean.valueOf(registros.getString(4)));
            encuestas.add(encuestaActual);
        }

        return encuestas;
    }

    /**
     * Método que permite insertar una encuesta en la base de datos.
     * @param db, base de datos a la cual se le insertara la encuesta.
     * @param encuesta, encuesta a insertar.
     */
    public void insertSurveys(DataBase db, Encuesta encuesta){

        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_ENCUESTA_NOMBRE, encuesta.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_ENCUESTA_FECHA, encuesta.getFechaCreacion() + "");
        contentValues.put(ConstantsDatabase.TABLE_ENCUESTA_CANTIDAD, encuesta.getCantidadPreguntas());
        contentValues.put(ConstantsDatabase.TABLE_ENCUESTA_VIGENCIA, encuesta.isVigente());

        db.insertRecord(ConstantsDatabase.TABLE_ENCUESTA, contentValues);
    }
}
