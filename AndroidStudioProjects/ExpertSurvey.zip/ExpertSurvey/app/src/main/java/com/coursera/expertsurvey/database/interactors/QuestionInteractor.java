package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Pregunta;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class QuestionInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public QuestionInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public QuestionInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar una pregunta.
     * @param db, base de datos donde se buscara la pregunta.
     * @param cod, identificador de la opcion a buscar.
     * @return pregunta, registro de la pregunta buscada.
     */
    public Pregunta searchQuestion(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_PREGUNTA_ID,
                ConstantsDatabase.TABLE_PREGUNTA_TEXTO, ConstantsDatabase.TABLE_PREGUNTA_NUMERO_FK,
                ConstantsDatabase.TABLE_PREGUNTA_TIPO_RESPUESTA_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_PREGUNTA,
                ConstantsDatabase.TABLE_PREGUNTA_ID, fields, parameters);

        Pregunta pregunta = new Pregunta();

        if (cursor.moveToFirst()) {
            pregunta.setIdPregunta(cursor.getInt(0));
            pregunta.setTexto(cursor.getString(1));
            pregunta.setNumeroEncuestaFK(cursor.getInt(2));
            pregunta.setTipoRespuestaFK(cursor.getInt(3));
        }

        return pregunta;
    }

    /**
     * Método que permite insertar una pregunta.
     * @param db, base de datos en la cual se insertara la pregunta.
     * @param pregunta, pregunta a insertar en la base de datos.
     */
    public void insertQuestion(DataBase db, Pregunta pregunta) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_PREGUNTA_TEXTO, pregunta.getTexto());
        contentValues.put(ConstantsDatabase.TABLE_PREGUNTA_NUMERO_FK, pregunta.getNumeroEncuestaFK());
        contentValues.put(ConstantsDatabase.TABLE_PREGUNTA_TIPO_RESPUESTA_FK, pregunta.getTipoRespuestaFK());

        db.insertRecord(ConstantsDatabase.TABLE_PREGUNTA, contentValues);
    }

    /**
     * Método que permite modificar el registro de una pregunta.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param pregunta, pregunta a la cual se le modificaran los datos.
     */
    public void modifyQuestion(DataBase db, Pregunta pregunta) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_PREGUNTA_ID, pregunta.getIdPregunta());
        contentValues.put(ConstantsDatabase.TABLE_PREGUNTA_TEXTO, pregunta.getTexto());
        contentValues.put(ConstantsDatabase.TABLE_PREGUNTA_NUMERO_FK, pregunta.getNumeroEncuestaFK());
        contentValues.put(ConstantsDatabase.TABLE_PREGUNTA_TIPO_RESPUESTA_FK, pregunta.getTipoRespuestaFK());

        db.editRecord(ConstantsDatabase.TABLE_PREGUNTA, contentValues, ConstantsDatabase.TABLE_PREGUNTA_ID,
                pregunta.getIdPregunta()+"");
    }

    /**
     * Método que permite eliminar una pregunta.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteQuestion(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_PREGUNTA, ConstantsDatabase.TABLE_PREGUNTA_ID, id+"");
    }

    /**
     * Método que permite obtener todas las preguntas.
     * @param db, base de datos donde se encuentran los registros.
     * @param idEncuesta, identificador de la encuesta a la cual pertenecen las preguntas a listar.
     * @return preguntas, lista de las preguntas registradas.
     */
    public ArrayList<Pregunta> getQuestionsSurvey(DataBase db, int idEncuesta) {
        String query = "SELECT * FROM " + ConstantsDatabase.TABLE_PREGUNTA + " WHERE " +
                ConstantsDatabase.TABLE_PREGUNTA_NUMERO_FK + " = " + idEncuesta;
        Cursor registros = db.getAllQuery(query);
        ArrayList<Pregunta> preguntas = new ArrayList<>();

        while (registros.moveToNext()) {
            Pregunta pregunta = new Pregunta();
            pregunta.setIdPregunta(registros.getInt(0));
            pregunta.setTexto(registros.getString(1));
            pregunta.setNumeroEncuestaFK(registros.getInt(2));
            pregunta.setTipoRespuestaFK(registros.getInt(3));
            preguntas.add(pregunta);
        }

        return preguntas;
    }
}
