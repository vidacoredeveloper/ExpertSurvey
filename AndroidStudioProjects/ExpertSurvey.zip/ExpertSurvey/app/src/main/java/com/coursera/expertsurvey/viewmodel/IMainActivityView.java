package com.coursera.expertsurvey.viewmodel;

import com.coursera.expertsurvey.adapters.ListAdapterSurvey;
import com.coursera.expertsurvey.pojo.Encuesta;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 12/12/16.
 */

public interface IMainActivityView {

    /**
     * Método que inicializa los componentes gráficos y lógicos que pertenecen a la vista.
     */
    public void initializeComponents();

    /**
     * Método que permite editar el shared.
     */
    public void editShared();

    /**
     * Método que permite verificar la carga de los datos de prueba.
     */
    public void verifyDummyData();

    /**
     * Método que permite la asignacion de la organización y orientación de los elementos
     * en le recycler view.
     */
    public void setLayoutRecyclerView();

    /**
     * Método que permite generar el adaptador de la lista de las encuestas.
     */
    public ListAdapterSurvey initializeListAdapterSurvey(ArrayList<Encuesta> encuestas);

    /**
     * Método que permite la inicialización del adaptador del recycler view.
     */
    public void initializeAdapterRecyclerView(ListAdapterSurvey listAdapterSurvey);
}
