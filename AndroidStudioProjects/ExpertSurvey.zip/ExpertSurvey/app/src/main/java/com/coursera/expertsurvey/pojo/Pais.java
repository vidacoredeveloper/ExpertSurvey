package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Pais {

    /**
     * Atributos de la clase
     */
    private int idPais;
    private String nombre;
    private int idContinenteFK;

    /**
     * Método constructor por default.
     */
    public Pais() {
    }

    /**
     * Método constructor.
     * @param nombre, valor que se va a establecer en el atributo.
     * @param idContinenteFK, identificador del continente al cual pertenece el pais.
     */
    public Pais(String nombre, int idContinenteFK) {
        this.nombre = nombre;
        this.idContinenteFK = idContinenteFK;
    }

    /**
     * Método accesor del atributo idPais.
     * @return idPais, valor del atributo establecido.
     */
    public int getIdPais() {
        return idPais;
    }

    /**
     * Método modificador correspondiente al valor del atributo idPais.
     * @param idPais, valor que se va a establecer en el atributo.
     */
    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    /**
     * Método accesor del atributo nombre.
     * @return nombre, valor del atributo establecido.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombre.
     * @param nombre, valor que se va a establecer en el atributo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método accesor del atributo idContinenteFK.
     * @return idContinenteFK, valor del atributo establecido.
     */
    public int getIdContinenteFK() {
        return idContinenteFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idContinenteFK.
     * @param idContinenteFK, valor que se va a establecer en el atributo.
     */
    public void setIdContinenteFK(int idContinenteFK) {
        this.idContinenteFK = idContinenteFK;
    }
}
