package com.coursera.expertsurvey.presenters.interfaces;

import com.coursera.expertsurvey.pojo.Encuesta;
import com.coursera.expertsurvey.pojo.Opcion;
import com.coursera.expertsurvey.pojo.PersonaEncuesta;
import com.coursera.expertsurvey.pojo.Pregunta;
import com.coursera.expertsurvey.pojo.Respuesta;
import com.coursera.expertsurvey.pojo.TipoRespuesta;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 20/12/16.
 */

public interface ISurveyActivityPresenter {

    /**
     * Método que permite buscar la una encuesta.
     * @param numEncuesta, identifiacdor de la encuesta a buscar.
     * @return encuesta, objeto de tipo encuesta buscado.
     */
    public Encuesta searchSurvey(int numEncuesta);

    /**
     * Método que permite obtener la lista de preguntas pertenecientes a una encuesta,
     * @param numEncuesta, identifiacdor de la encuesta para obtener las preguntas.
     * @return preguntas, lista de preguntas pertenecientes a una sola encuesta.
     */
    public ArrayList<Pregunta> listQuestions(int numEncuesta);

    /**
     * Método que permite obtener la lista de opciones pertenecientes a una pregunta.
     * @param idPregunta, identificador de la pregunta para obtener las opciones.
     * @return opciones, lista de opciones pertenecientes a una sola pregunta.
     */
    public ArrayList<Opcion> listOptions(int idPregunta);

    /**
     * Método que permite mostrar la lista de opciones en la vista.
     * @param tipoRespuesta, tipo de respuesta que permite determinar los componentes de la vista a cargar.
     * @param opciones, lista de opciones a mostrar en la vista.
     */
    public void showOptionsListView(TipoRespuesta tipoRespuesta, ArrayList<Opcion> opciones);

    /**
     * Método que permite guardar una persona encuesta.
     * @param personaEncuesta, persona encuesta a guardar.
     */
    public void savePersonSurvey(PersonaEncuesta personaEncuesta);

    /**
     * Método que permite buscar una persona encuesta.
     */
    public PersonaEncuesta searchPersonSurvey(int typeDoc, String doc, int numSurv);

    /**
     * Método que permite guardar la respuesta a una pregunta de la encuesta.
     */
    public void saveResponse(Respuesta respuesta);

    /**
     * Método que permite buscar el tipo de respuesta.
     * @param idTipo, identificador del tipo de respuesta a buscar.
     * @return tipoRespuesta, objeto de tipo respuesta buscado.
     */
    public TipoRespuesta getTypeResponse(int idTipo);
}
