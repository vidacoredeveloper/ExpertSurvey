package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Respuesta;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class ResponseInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public ResponseInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public ResponseInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar una respuesta.
     * @param db, base de datos donde se buscara la respuesta.
     * @param cod, identificador de la respuesta a buscar.
     * @return respuesta, registro de la respuesta buscada.
     */
    public Respuesta searchResponse(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_REGION_ID,
                ConstantsDatabase.TABLE_RESPUESTA_VALOR, ConstantsDatabase.TABLE_RESPUESTA_PREGUNTA_FK,
                ConstantsDatabase.TABLE_RESPUESTA_PERSONA_ENCUESTA_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_RESPUESTA,
                ConstantsDatabase.TABLE_RESPUESTA_ID, fields, parameters);

        Respuesta respuesta = new Respuesta();

        if (cursor.moveToFirst()) {
            respuesta.setIdRespuesta(cursor.getInt(0));
            respuesta.setValor(cursor.getInt(1));
            respuesta.setIdPreguntaFK(cursor.getInt(2));
            respuesta.setIdPersonaEncuestaFK(cursor.getInt(3));
        }

        return respuesta;
    }

    /**
     * Método que permite insertar una respuesta.
     * @param db, base de datos en la cual se insertara la respuesta.
     * @param respuesta, respuesta a insertar en la base de datos.
     */
    public void insertResponse(DataBase db, Respuesta respuesta) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_RESPUESTA_VALOR, respuesta.getValor());
        contentValues.put(ConstantsDatabase.TABLE_RESPUESTA_PREGUNTA_FK, respuesta.getIdPreguntaFK());
        contentValues.put(ConstantsDatabase.TABLE_RESPUESTA_PERSONA_ENCUESTA_FK, respuesta.getIdPersonaEncuestaFK());

        db.insertRecord(ConstantsDatabase.TABLE_RESPUESTA, contentValues);
    }

    /**
     * Método que permite modificar el registro de una respuesta.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param respuesta, respuesta a la cual se le modificaran los datos.
     */
    public void modifyResponse(DataBase db, Respuesta respuesta) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_RESPUESTA_VALOR, respuesta.getValor());
        contentValues.put(ConstantsDatabase.TABLE_RESPUESTA_PREGUNTA_FK, respuesta.getIdPreguntaFK());
        contentValues.put(ConstantsDatabase.TABLE_RESPUESTA_PERSONA_ENCUESTA_FK, respuesta.getIdPersonaEncuestaFK());

        db.editRecord(ConstantsDatabase.TABLE_RESPUESTA, contentValues, ConstantsDatabase.TABLE_RESPUESTA_ID,
                respuesta.getIdRespuesta()+"");
    }

    /**
     * Método que permite eliminar una respuesta.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteResponse(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_RESPUESTA, ConstantsDatabase.TABLE_RESPUESTA_ID, id+"");
    }

    /**
     * Método que permite obtener todas las respuestas.
     * @param db, base de datos donde se encuentran los registros.
     * @return respuestas, lista de las respuestas registradas.
     */
    public ArrayList<Respuesta> getResponses(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_RESPUESTA);
        ArrayList<Respuesta> respuestas = new ArrayList<>();

        while (registros.moveToNext()) {
            Respuesta respuesta = new Respuesta();
            respuesta.setIdRespuesta(registros.getInt(0));
            respuesta.setValor(registros.getInt(1));
            respuesta.setIdPreguntaFK(registros.getInt(2));
            respuesta.setIdPersonaEncuestaFK(registros.getInt(3));
            respuestas.add(respuesta);
        }

        return respuestas;
    }
}
