package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.Contacto;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class ContactInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public ContactInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public ContactInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar un contacto.
     * @param db, base de datos donde se buscara el contacto.
     * @param cod, identificador del contacto a buscar.
     * @return contacto, registro del contacto buscado.
     */
    public Contacto searchContact(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_CONTACTO_ID,
                ConstantsDatabase.TABLE_CONTACTO_EMAIL, ConstantsDatabase.TABLE_CONTACTO_COD_AREA_TEL,
                ConstantsDatabase.TABLE_CONTACTO_COD_PAIS_TEL, ConstantsDatabase.TABLE_CONTACTO_NUM_TEL,
                ConstantsDatabase.TABLE_CONTACTO_DOCUMENTO_FK, ConstantsDatabase.TABLE_CONTACTO_TIPO_CONTACTO_FK,
                ConstantsDatabase.TABLE_CONTACTO_TIPO_DOCUMENTO_FK};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_CONTACTO,
                ConstantsDatabase.TABLE_CONTACTO_ID, fields, parameters);

        Contacto contacto = new Contacto();

        if (cursor.moveToFirst()) {
            contacto.setIdContacto(cursor.getInt(0));
            contacto.setEmail(cursor.getString(1));
            contacto.setCodAreaTel(cursor.getString(2));
            contacto.setCodPaisTel(cursor.getString(3));
            contacto.setNumeroTel(cursor.getString(4));
            contacto.setDocumentoFK(cursor.getString(5));
            contacto.setIdTipoContactoFK(cursor.getInt(6));
            contacto.setIdTipoDocumentoFK(cursor.getInt(7));
        }

        return contacto;
    }

    /**
     * Método que permite insertar un contacto.
     * @param db, base de datos en la cual se insertara el contacto.
     * @param contacto, contacto a insertar en la base de datos.
     */
    public void insertContact(DataBase db, Contacto contacto) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_EMAIL, contacto.getEmail());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_COD_AREA_TEL, contacto.getCodAreaTel());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_COD_PAIS_TEL, contacto.getCodPaisTel());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_NUM_TEL, contacto.getNumeroTel());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_DOCUMENTO_FK, contacto.getDocumentoFK());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_TIPO_CONTACTO_FK, contacto.getIdTipoContactoFK());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_TIPO_DOCUMENTO_FK, contacto.getIdTipoDocumentoFK());

        db.insertRecord(ConstantsDatabase.TABLE_CONTACTO, contentValues);
    }

    /**
     * Método que permite modificar el registro de un contacto.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param contacto, contacto a la cual se le modificaran los datos.
     */
    public void modifyContact(DataBase db, Contacto contacto) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_ID, contacto.getIdContacto());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_EMAIL, contacto.getEmail());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_COD_AREA_TEL, contacto.getCodAreaTel());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_COD_PAIS_TEL, contacto.getCodPaisTel());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_NUM_TEL, contacto.getNumeroTel());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_DOCUMENTO_FK, contacto.getDocumentoFK());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_TIPO_CONTACTO_FK, contacto.getIdTipoContactoFK());
        contentValues.put(ConstantsDatabase.TABLE_CONTACTO_TIPO_DOCUMENTO_FK, contacto.getIdTipoDocumentoFK());

        db.editRecord(ConstantsDatabase.TABLE_CONTACTO, contentValues, ConstantsDatabase.TABLE_CONTACTO_ID,
                contacto.getIdContacto()+"");
    }

    /**
     * Método que permite eliminar un contacto.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteContact(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_CONTACTO, ConstantsDatabase.TABLE_CONTACTO_ID, id+"");
    }

    /**
     * Método que permite obtener todos los contacto.
     * @param db, base de datos donde se encuentran los registros.
     * @return ciudades, lista de los contactos registrados.
     */
    public ArrayList<Contacto> getContacts(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_CONTACTO);
        ArrayList<Contacto> contactos = new ArrayList<>();

        while (registros.moveToNext()) {
            Contacto contacto = new Contacto();
            contacto.setIdContacto(registros.getInt(0));
            contacto.setEmail(registros.getString(1));
            contacto.setCodAreaTel(registros.getString(3));
            contacto.setCodPaisTel(registros.getString(2));
            contacto.setNumeroTel(registros.getString(4));
            contacto.setDocumentoFK(registros.getString(6));
            contacto.setIdTipoContactoFK(registros.getInt(5));
            contacto.setIdTipoDocumentoFK(registros.getInt(7));
            contactos.add(contacto);
        }

        return contactos;
    }

    /**
     * Método que permite obtener todos los contacto.
     * @return ciudades, lista de los contactos registrados.
     */
    public ArrayList<Contacto> getContactsPerson(int type, String documento) {
        DataBase db = new DataBase(context);
        Cursor registros = db.getAllCompositeKey(ConstantsDatabase.TABLE_CONTACTO,
                ConstantsDatabase.TABLE_CONTACTO_TIPO_DOCUMENTO_FK, type,
                ConstantsDatabase.TABLE_CONTACTO_DOCUMENTO_FK, documento);
        ArrayList<Contacto> contactos = new ArrayList<>();

        while (registros.moveToNext()) {
            Contacto contacto = new Contacto();
            contacto.setIdContacto(registros.getInt(0));
            contacto.setEmail(registros.getString(1));
            contacto.setCodAreaTel(registros.getString(3));
            contacto.setCodPaisTel(registros.getString(2));
            contacto.setNumeroTel(registros.getString(4));
            contacto.setDocumentoFK(registros.getString(6));
            contacto.setIdTipoContactoFK(registros.getInt(5));
            contacto.setIdTipoDocumentoFK(registros.getInt(7));
            contactos.add(contacto);
        }

        return contactos;
    }
}
