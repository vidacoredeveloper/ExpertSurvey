package com.coursera.expertsurvey;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.coursera.expertsurvey.pojo.Encuesta;
import com.coursera.expertsurvey.pojo.Opcion;
import com.coursera.expertsurvey.pojo.PersonaEncuesta;
import com.coursera.expertsurvey.pojo.Pregunta;
import com.coursera.expertsurvey.pojo.Respuesta;
import com.coursera.expertsurvey.presenters.SurveyActivityPresenter;
import com.coursera.expertsurvey.presenters.interfaces.ISurveyActivityPresenter;
import com.coursera.expertsurvey.viewmodel.ISurveyActivityView;

import java.util.ArrayList;
import java.util.Calendar;

public class SurveyActivity extends AppCompatActivity implements ISurveyActivityView {

    /**
     * Componentes de la vista.
     */
    private Button btnNextAS;
    private ListView lvOptionsQuestionAS;
    private TextView tvNumberQuestionAS, tvQuestionAS;

    /**
     * Atributos de la vista.
     */
    private Encuesta encuesta;
    private int posicionPregunta;
    public static boolean estadoRespuesta;
    private ArrayList<Pregunta> preguntas;
    public static PersonaEncuesta personaEncuesta;
    private ISurveyActivityPresenter iSurveyActivityPresenter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);
        initializeComponents();
    }

    /**
     * Método que inicializa los componentes gráficos y lógicos que pertenecen a la vista.
     */
    @Override
    public void initializeComponents() {
        posicionPregunta = 0;
        estadoRespuesta = false;
        personaEncuesta = new PersonaEncuesta();
        btnNextAS = (Button) findViewById(R.id.btnNextAS);
        tvQuestionAS = (TextView) findViewById(R.id.tvQuestionAS);
        lvOptionsQuestionAS = (ListView) findViewById(R.id.lvOptionsQuestionAS);
        tvNumberQuestionAS = (TextView) findViewById(R.id.tvNumberQuestionAS);

        iSurveyActivityPresenter = new SurveyActivityPresenter(getBaseContext(), this);
        getSurvey();
    }

    /**
     * Método que permite buscar los datos de una encuesta.
     */
    @Override
    public void getSurvey() {
        encuesta = iSurveyActivityPresenter.searchSurvey(getIntent().getExtras().getInt("idSurvey"));
        loadListQuestions();
    }

    /**
     * Método que permite cargar la lista de preguntas.
     */
    @Override
    public void loadListQuestions() {
        if(encuesta != null) {
            preguntas = iSurveyActivityPresenter.listQuestions(encuesta.getNumero());
            if(preguntas != null) {
                loadListOptions();
            }
            else {
                Toast.makeText(this, "No se pudo cargar la lista de preguntas", Toast.LENGTH_LONG).show();
            }
        }
        else {
            Toast.makeText(this, "No se encontro la encuesta", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Método que permite cargar la lista de opciones.
     */
    @Override
    public void loadListOptions() {
        if(preguntas.size() > 0) {
            Log.d("POS_QUESTION_AS", posicionPregunta + "");
            Pregunta pregunta = preguntas.get(posicionPregunta);
            Log.d("POS_QUESTION_AS", MainActivity.preguntas.size() + "");
            MainActivity.preguntas.add(pregunta);
            tvNumberQuestionAS.setText(pregunta.getIdPregunta() + "");
            tvQuestionAS.setText(pregunta.getTexto());
            iSurveyActivityPresenter.showOptionsListView(iSurveyActivityPresenter.getTypeResponse(pregunta.getTipoRespuestaFK()),
                    iSurveyActivityPresenter.listOptions(preguntas.get(posicionPregunta).getIdPregunta()));
        }
        else {
            Toast.makeText(this, "No hay preguntas para cargar", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Método que permite continuar con la siguiente pregunta de la encuesta.
     * @param view, vista desde la cual se hace el llamado del método.
     */
    @Override
    public void nextQuestion(View view) {
        posicionPregunta = posicionPregunta + 1;
        if(posicionPregunta > preguntas.size()-1){
            if(!estadoRespuesta){
                savePersonSurvey();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            }
            else{
                MainActivity.opcionesRespondidas.add(MainActivity.opcionRespondida);
                estadoRespuesta = false;
                savePersonSurvey();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }
        }
        else if(posicionPregunta == preguntas.size()-1){
            btnNextAS.setText(getResources().getString(R.string.activity_survey_btn_next_option_text_fin));
            if(!estadoRespuesta){
                loadListOptions();
            }
            else{
                MainActivity.opcionesRespondidas.add(MainActivity.opcionRespondida);
                estadoRespuesta = false;
                loadListOptions();
            }
        }
        else {
            btnNextAS.setText(getResources().getString(R.string.activity_survey_btn_next_option_text));
            if(!estadoRespuesta){
                loadListOptions();
            }
            else{
                MainActivity.opcionesRespondidas.add(MainActivity.opcionRespondida);
                estadoRespuesta = false;
                loadListOptions();
            }
        }
    }

    /**
     * Método que permite la inicialización del adaptador del list view.
     * @param adapter, lista de los items que se mostraran en el list view.
     */
    @Override
    public void initializeAdapterListView(ArrayAdapter adapter) {
        lvOptionsQuestionAS.setAdapter(adapter);
    }

    /**
     * Método que permite guardar una persona encuesta.
     */
    @Override
    public void savePersonSurvey() {
        PersonaEncuesta personaEncuesta = new PersonaEncuesta();
        personaEncuesta.setNumeroEncuestaFK(MainActivity.encuesta.getNumero());
        personaEncuesta.setIdTipoDocumentoFK(MainActivity.persona.getIdTipoDocumentoFK());
        personaEncuesta.setDocumentoFK(MainActivity.persona.getDocumento());
        personaEncuesta.setFecha(Calendar.getInstance().getTime());
        personaEncuesta.setEstado("Activo");

        iSurveyActivityPresenter.savePersonSurvey(personaEncuesta);

        personaEncuesta = iSurveyActivityPresenter.searchPersonSurvey(MainActivity.persona.getIdTipoDocumentoFK(),
                MainActivity.persona.getDocumento(), MainActivity.encuesta.getNumero());

        saveSurveyResponses();
    }

    /**
     * Método que permite guardar las respuestas de la encuesta.
     */
    @Override
    public void saveSurveyResponses() {
        for(int i=0; i<MainActivity.preguntas.size(); i++){
            Respuesta respuesta = new Respuesta();
            respuesta.setIdPersonaEncuestaFK(personaEncuesta.getIdEncuestaPersona());
            respuesta.setIdPreguntaFK(MainActivity.opcionesRespondidas.get(i).getIdPreguntaFK());
            respuesta.setValor(MainActivity.opcionesRespondidas.get(i).getValor());

            iSurveyActivityPresenter.saveResponse(respuesta);
        }
    }

    /**
     * Método que permite generar un escuchador a los items del list view.
     * @param opciones, lista de las opciones mostradas en el list view.
     */
    public void listItemListenerCombo(final ArrayList<Opcion> opciones) {
        lvOptionsQuestionAS.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        lvOptionsQuestionAS.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                CheckedTextView item = (CheckedTextView) view;
                String mos = opciones.get(i).getEtiqueta();
                estadoRespuesta = true;
                MainActivity.opcionRespondida = opciones.get(i);
            }
        });
    }

    /**
     * Método que permite generar un escuchador a los items del list view.
     * @param opciones, lista de las opciones mostradas en el list view.
     */
    @Override
    public void listItemListenerCheck(final ArrayList<Opcion> opciones) {
        lvOptionsQuestionAS.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        lvOptionsQuestionAS.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                CheckedTextView item = (CheckedTextView) view;
                if(item.isChecked()){
                    MainActivity.opcionesRespondidas.add(opciones.get(i));
                }
                else {
                    MainActivity.opcionesRespondidas.remove(opciones.get(i));
                }
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK){
            Intent intent = new Intent(SurveyActivity.this, ProfileActivity.class);
            startActivity(intent);
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
