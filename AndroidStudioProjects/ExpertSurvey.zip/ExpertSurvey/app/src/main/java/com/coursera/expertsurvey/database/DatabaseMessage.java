package com.coursera.expertsurvey.database;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class DatabaseMessage {
    /**
     * Atributos de la clase.
     */
    private String message;
    private String table;
    private String type;
    private Context context;

    /**
     * Variables de tipificación de la clase.
     */
    public static final String MESSAGE_ERROR = "ERROR";

    /**
     * Método constructor por default de la clase.
     */
    public DatabaseMessage() {
    }

    /**
     * Método constructor de la clase.
     * @param message, mensaje a mostrar.
     * @param table, tabla a la cual no se pudo realizar la acción.
     * @param type, tipo de mensaje a morstrar.
     */
    public DatabaseMessage(String message, String table, String type, Context context) {
        this.message = message;
        this.table = table;
        this.type = type;
        this.context = context;
    }

    /**
     * Método accesor del atributo message.
     * @return message, valor del atributo establecido.
     */
    public String getMessage() {
        return message;
    }

    /**
     * Método modificador correspondiente al valor del atributo message.
     * @param message, valor que se va a establecer en el atributo.
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Método accesor del atributo table.
     * @return table, valor del atributo establecido.
     */
    public String getTable() {
        return table;
    }

    /**
     * Método modificador correspondiente al valor del atributo table.
     * @param table, valor que se va a establecer en el atributo.
     */
    public void setTable(String table) {
        this.table = table;
    }

    /**
     * Método accesor del atributo type.
     * @return type, valor del atributo establecido.
     */
    public String getType() {
        return type;
    }

    /**
     * Método modificador correspondiente al valor del atributo type.
     * @param type, valor que se va a establecer en el atributo.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Método accesor del atributo context.
     * @return context, valor del atributo establecido.
     */
    public Context getContext() {
        return context;
    }

    /**
     * Método modificador correspondiente al valor del atributo context.
     * @param context, valor que se va a establecer en el atributo.
     */
    public void setContext(Context context) {
        this.context = context;
    }

    /**
     * Método que permite mostrar un mensaje.
     * @param type, tipo del mensaje a mostarar.
     */
    public void mostrarMensaje(String type){
        switch (type) {
            case MESSAGE_ERROR:

                Toast.makeText(context, message, Toast.LENGTH_LONG);

                break;
        }
    }
}
