package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Ciudad {

    /**
     * Atributos de la clase.
     */
    private int idCiudad;
    private String nombre;
    private int idDepartamentoFK;

    /**
     * Método constructor por default de la clase.
     */
    public Ciudad() {
    }

    /**
     * Método constructor de la clase.
     * @param nombre, valor que se va a establecer en el atributo.
     * @param idDepartamentoFK, departamento al que pertenece la ciudad.
     */
    public Ciudad(String nombre, int idDepartamentoFK) {
        this.nombre = nombre;
        this.idDepartamentoFK = idDepartamentoFK;
    }

    /**
     * Método accesor del atributo idCiudad.
     * @return idCiudad, valor del atributo establecido.
     */
    public int getIdCiudad() {
        return idCiudad;
    }

    /**
     * Método modificador correspondiente al valor del atributo idCiudad.
     * @param idCiudad, valor que se va a establecer en el atributo.
     */
    public void setIdCiudad(int idCiudad) {
        this.idCiudad = idCiudad;
    }

    /**
     * Método accesor del atributo nombre.
     * @return nombre, valor del atributo establecido.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombre.
     * @param nombre, valor que se va a establecer en el atributo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método accesor del atributo idDepartamentoFK.
     * @return idDepartamentoFK, valor del atributo establecido.
     */
    public int getIdDepartamentoFK() {
        return idDepartamentoFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idDepartamentoFK.
     * @param idDepartamentoFK, valor que se va a establecer en el atributo.
     */
    public void setIdDepartamentoFK(int idDepartamentoFK) {
        this.idDepartamentoFK = idDepartamentoFK;
    }
}
