package com.coursera.expertsurvey.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;

import com.coursera.expertsurvey.R;
import com.coursera.expertsurvey.pojo.Opcion;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 28/12/16.
 */

public class ListAdapterQuestionOption extends ArrayAdapter<Opcion> {

    private String tipoRespuesta;

    /**
     * Método constructor de la clase.
     * @param opciones, lista de objetos tipo opcion.
     */
    public ListAdapterQuestionOption(Context context, ArrayList<Opcion> opciones, String tipoRespuesta) {
        super(context, 0, opciones);
        notifyDataSetChanged();
        this.tipoRespuesta = tipoRespuesta;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (null == convertView) {
            convertView = changeView(convertView, inflater, parent, position);
        }

        return convertView;
    }

    /**
     * Método que permite determinar el tipo de vista según el tipo de respuesta.
     * @param convertView, vista que se piensa convertir.
     * @param inflater, inflador de la vista.
     * @param parent, padre del grupo de vistas.
     * @param position, posicion del elemento a mostrar en la vista.
     * @return convertView, vista con los cambios realizados.
     */
    private View changeView(View convertView, LayoutInflater inflater, ViewGroup parent, int position){
        if(tipoRespuesta.equals("Unica")){
            convertView = inflater.inflate(
                    android.R.layout.simple_list_item_single_choice,
                    parent,
                    false);

            CheckedTextView text1 = (CheckedTextView) convertView.findViewById(android.R.id.text1);
            Opcion opcion = getItem(position);

            text1.setText(opcion.getEtiqueta());
        }
        else {
            convertView = inflater.inflate(
                    R.layout.list_check_item,
                    parent,
                    false);

            CheckedTextView checkedTextView1 = (CheckedTextView) convertView.findViewById(R.id.checkedTextView1);
            Opcion opcion = getItem(position);

            checkedTextView1.setText(opcion.getEtiqueta());
        }
        return convertView;
    }
}
