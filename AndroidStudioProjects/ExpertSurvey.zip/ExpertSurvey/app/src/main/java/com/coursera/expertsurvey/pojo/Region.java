package com.coursera.expertsurvey.pojo;

/**
 * Created by Victor Daniel Cortés Restrepo on 9/12/16.
 */

public class Region {

    /**
     * Atributos de la clase.
     */
    private int idRegion;
    private String nombre;
    private int idPaisFK;

    /**
     * Método constructor por default de la clase.
     */
    public Region() {
    }

    /**
     * Método constructor de la clase.
     * @param nombre, valor que se va a establecer en el atributo.
     * @param idPaisFK, valor que se va a establecer en el atributo.
     */
    public Region(String nombre, int idPaisFK) {
        this.nombre = nombre;
        this.idPaisFK = idPaisFK;
    }

    /**
     * Método accesor del atributo idRegion.
     * @return idRegion, valor del atributo establecido.
     */
    public int getIdRegion() {
        return idRegion;
    }

    /**
     * Método modificador correspondiente al valor del atributo idRegion.
     * @param idRegion, valor que se va a establecer en el atributo.
     */
    public void setIdRegion(int idRegion) {
        this.idRegion = idRegion;
    }

    /**
     * Método accesor del atributo nombre.
     * @return nombre, valor del atributo establecido.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método modificador correspondiente al valor del atributo nombre.
     * @param nombre, valor que se va a establecer en el atributo.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Método accesor del atributo idPaisFK.
     * @return idPaisFK, valor del atributo establecido.
     */
    public int getIdPaisFK() {
        return idPaisFK;
    }

    /**
     * Método modificador correspondiente al valor del atributo idPaisFK.
     * @param idPaisFK, valor que se va a establecer en el atributo.
     */
    public void setIdPaisFK(int idPaisFK) {
        this.idPaisFK = idPaisFK;
    }
}
