package com.coursera.expertsurvey.presenters;

import android.content.Context;

import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.database.interactors.SurveyInteractor;
import com.coursera.expertsurvey.pojo.Encuesta;
import com.coursera.expertsurvey.presenters.interfaces.IMainActivityPresenter;
import com.coursera.expertsurvey.viewmodel.IMainActivityView;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 13/12/16.
 */

public class MainActivityPresenter implements IMainActivityPresenter {

    /**
     * Atributos de la clase.
     */
    private IMainActivityView iMainActivityView;
    private Context context;
    private SurveyInteractor interactor;
    private ArrayList<Encuesta> surveys;

    /**
     * Método constructor de la clase.
     * @param iMainActivityView, instacia de la interface de la vista principal.
     * @param context, contexto de la vista principal.
     */
    public MainActivityPresenter(IMainActivityView iMainActivityView, Context context) {
        this.iMainActivityView = iMainActivityView;
        this.context = context;
        getSurveysDataBase();
    }

    /**
     * Método que permite extraer las encuestas de la base de datos.
     */
    @Override
    public void getSurveysDataBase() {
        interactor = new SurveyInteractor(context);
        surveys = interactor.getSurveys(new DataBase(context));
        showPollsReclyclerView();
    }

    /**
     * Método que permite mostrar las encuestas en la vista.
     */
    @Override
    public void showPollsReclyclerView() {
        iMainActivityView.initializeAdapterRecyclerView(iMainActivityView.initializeListAdapterSurvey(surveys));
        iMainActivityView.setLayoutRecyclerView();
    }
}
