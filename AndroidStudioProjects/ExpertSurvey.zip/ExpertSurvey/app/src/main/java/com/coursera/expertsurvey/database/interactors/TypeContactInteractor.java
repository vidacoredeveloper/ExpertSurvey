package com.coursera.expertsurvey.database.interactors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.coursera.expertsurvey.database.ConstantsDatabase;
import com.coursera.expertsurvey.database.DataBase;
import com.coursera.expertsurvey.pojo.TipoContacto;

import java.util.ArrayList;

/**
 * Created by Victor Daniel Cortés Restrepo on 15/12/16.
 */

public class TypeContactInteractor {

    /**
     * Atributos de la clase.
     */
    private Context context;

    /**
     * Método constructor por default.
     */
    public TypeContactInteractor() {
    }

    /**
     * Método constructor de la clase.
     * @param context, contexto de la vista con la que se va a interactura.
     */
    public TypeContactInteractor(Context context) {
        this.context = context;
    }

    /**
     * Método que permite buscar un tipo contacto.
     * @param db, base de datos donde se buscara el tipo contacto.
     * @param cod, identificador del tipo contacto a buscar.
     * @return tipoContacto, registro del tipo contacto buscado.
     */
    public TipoContacto searchTypeContact(DataBase db, int cod) {
        String [] parameters = {cod+""};
        String [] fields = {ConstantsDatabase.TABLE_TIPO_CONTACTO_ID,
                ConstantsDatabase.TABLE_TIPO_CONTACTO_NOMBRE, ConstantsDatabase.TABLE_TIPO_CONTACTO_DESCRIPCION};

        Cursor cursor = db.searchRecord(ConstantsDatabase.TABLE_TIPO_CONTACTO,
                ConstantsDatabase.TABLE_TIPO_CONTACTO_ID, fields, parameters);

        TipoContacto tipoContacto = new TipoContacto();

        if (cursor.moveToFirst()) {
            tipoContacto.setIdTipoContacto(cursor.getInt(0));
            tipoContacto.setNombre(cursor.getString(1));
            tipoContacto.setDescripcion(cursor.getString(2));
        }

        return tipoContacto;
    }

    /**
     * Método que permite insertar un tipoContacto.
     * @param db, base de datos en la cual se insertara el tipoContacto.
     * @param tipoContacto, tipoContacto a insertar en la base de datos.
     */
    public void insertTypeContact(DataBase db, TipoContacto tipoContacto) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_TIPO_CONTACTO_NOMBRE, tipoContacto.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_CONTACTO_DESCRIPCION, tipoContacto.getDescripcion());

        db.insertRecord(ConstantsDatabase.TABLE_TIPO_CONTACTO, contentValues);
    }

    /**
     * Método que permite modificar el registro de un tipoContacto.
     * @param db, base de datos donde se encuentra el registro a modificar.
     * @param tipoContacto, tipoContacto a la cual se le modificaran los datos.
     */
    public void modifyTypeContact(DataBase db, TipoContacto tipoContacto) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantsDatabase.TABLE_TIPO_CONTACTO_ID, tipoContacto.getIdTipoContacto());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_CONTACTO_NOMBRE, tipoContacto.getNombre());
        contentValues.put(ConstantsDatabase.TABLE_TIPO_CONTACTO_DESCRIPCION, tipoContacto.getDescripcion());

        db.editRecord(ConstantsDatabase.TABLE_TIPO_CONTACTO, contentValues, ConstantsDatabase.TABLE_TIPO_CONTACTO_ID,
                tipoContacto.getIdTipoContacto()+"");
    }

    /**
     * Método que permite eliminar un tipo contacto.
     * @param db, base de datos en la cual se encuentra el registro a eliminar.
     * @param id, identificador del registro a eliminar.
     */
    public void deleteTypeContact(DataBase db, int id) {
        db.deleteRecord(ConstantsDatabase.TABLE_TIPO_CONTACTO, ConstantsDatabase.TABLE_TIPO_CONTACTO_ID, id+"");
    }

    /**
     * Método que permite obtener todos los tipos contacto.
     * @param db, base de datos donde se encuentran los registros.
     * @return tiposContacto, lista de los tipos contacto registrados.
     */
    public ArrayList<TipoContacto> getTypesContact(DataBase db) {
        Cursor registros = db.getAll(ConstantsDatabase.TABLE_CONTACTO);
        ArrayList<TipoContacto> tiposContacto = new ArrayList<>();

        while (registros.moveToNext()) {
            TipoContacto tipoContacto = new TipoContacto();
            tipoContacto.setIdTipoContacto(registros.getInt(0));
            tipoContacto.setNombre(registros.getString(1));
            tipoContacto.setDescripcion(registros.getString(2));
            tiposContacto.add(tipoContacto);
        }

        return tiposContacto;
    }


}
